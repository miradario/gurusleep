import moment from "moment";


export const today = () => {
  return  moment(new Date()); 
 }


 export const today_plus = (cant) => {

  let tomorrow = new Date();
  return moment(tomorrow).add(cant, 'day').format('YYYY-MM-DD'); 
   }
 
export const completed_days = (x) => {

    let cant=0;
    for (i=1;  i<=21; i++)
    {
        cant=cant + parseInt(x["day"+i]);
       
       

    }

    return cant;
} 

export const current_day = (daystarted) => {
  const today = moment(new Date());
  const startday = moment(daystarted, 'YYYY-MM-DD');
  let curr = today.diff(startday, 'days') + 1;
  if (startday > today) { return -1; }
  if (curr >= 21) { return 21; } else { return curr }
}

export const finished = (currentday) => {
  if (currentday >= 21) { return true; } else { return false }
}

export const abandoned = (finished, daychecked, completed, current_day) => {
  let todaynotabadon = 0;
  if (daychecked == 0 && finished == 0) {
    todaynotabadon = 1;
  }


  
  let abandon = current_day - completed - todaynotabadon;

  return abandon;
}