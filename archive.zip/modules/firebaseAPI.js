import * as firebase from "firebase";

//import react in our code.
import { Alert } from "react-native";
import i18n from "i18n-js";

// export const firebaseDatabase = firebase.database()
const userLanguage = i18n.locale.toUpperCase();

export const createUser = (email, password) => {
  firebase
    .auth()
    .createUserWithEmailAndPassword(email, password)
    .catch(error => Alert.alert("Login Error", "Create user error: " + error))
    .then(res => {
      firebase
        .database()
        .ref("Users/" + res.user.uid)
        .set({
          email: email,
          password: password
        })
        .catch(error =>
          Alert.alert("Database Error", "create user : " + error)
        );
    });
};

export const getUser = async () => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("/Users/" + userId );
 
  const result = await source.once('value')
  return result.val()
}

export const UpdateUser = (
  userId,
  name,
  email,
  password,
  company,
  language
) => {
  this.database = firebase.database();

  const update = {
    displayName: name,
    email: email,
    company: company,
    language: language,
  };
  database
    .ref("/Users/" + userId)
    .update(update)

    .catch(function(error) {
      alert(error.message);
    });
};

export const signInUser = async (email, password) => {
  await firebase
    .auth()
    .signInWithEmailAndPassword(email, password)
    .catch(error => {
      Alert.alert("Login Error", "Sign in error: " + error)
    });
};

export const logoutUser = () => {
  firebase.auth().signOut();
};

export const createChallenge = (
  title,
  what,
  why,
  how,
  succesful,
  problems,
  startDate,
  image
) => {
  this.database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  this.database.ref("Users/" + userId + "/Challenge/").push({
    title: title,
    what: what,
    why: why,
    how: how,
    succesful: succesful,
    problems: problems,
    image: image,
    daystart: startDate,
    completed: 0,
    abandoned: 0,
    current_day: 0,
    active: "current",
    day: 0,
    day1: 0,
    day2: 0,
    day3: 0,
    day4: 0,
    day5: 0,
    day6: 0,
    day7: 0,
    day8: 0,
    day9: 0,
    day10: 0,
    day11: 0,
    day12: 0,
    day13: 0,
    day14: 0,
    day15: 0,
    day16: 0,
    day17: 0,
    day18: 0,
    day19: 0,
    day20: 0,
    day21: 0
  });
};

export const updateChallenge = (
  pkey,
  title,
  what,
  why,
  how,
  succesful,
  problems,
  image
) => {
  this.database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  this.database.ref("Users/" + userId + "/Challenge/" + pkey).update({
    title: title,
    what: what,
    why: why,
    how: how,
    succesful: succesful,
    problems: problems,
    image: image
  });
};

export const deleteChallenge = pkey => {
  this.database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  this.database.ref("Users/" + userId + "/Challenge/" + pkey).update({
    active: "deleted"
  });
};

export const getResources = () => {
  const database = firebase.database();
  const source = database.ref("/Customer/Telekom/WorkshopResource/GE");
  return source.once("value");
};

export const getChallenge = async challengeID => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("/Users/" + userId + "/Challenge/" + challengeID);
  const result = await source.once("value");
  return result.val();
};

export const getPhrases = async () => {
  const database = firebase.database();
  const source = database.ref("/phrases/" + userLanguage);
  const result = await source.once("value");
  return result.val();
};

export const getMeditation = async meditationID => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const lang =  i18n.locale.toUpperCase();

  const source = database.ref(
    "/Assets/" +  lang + "/" + category + "/" + meditationID
  );
  const result = await source.once("value");
  return result.val();
};

export const getContent = async category => {
  const database = firebase.database();
  const lang =  i18n.locale.toUpperCase();
  const source = database.ref("/Assets/" + lang + "/" + category);
  const result = await source.once("value");
  const resources = [];
  result.forEach(data => {
    let resource = data.val();
    resource.id = data.key;
    resources.push(resource);
  });
  return resources;
};

export const getFavourites = async () => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("/Users/" + userId + "/Fav");
  const result = await source.once("value");
  const favs = [];
  result.forEach(data => {
    let fav = data.val();
    fav.id = data.key;
    favs.push(fav);
  });
  return favs;
};

export const getFavsContent = async () => {
  const database = firebase.database();
  let favs = await getFavouritesID();
  const source = database.ref("/Assets/" + userLanguage);
  const result = await source.once("value");
  const favsContent = [];
  result.forEach(data => {
    if (data.key != "List") {
      data.forEach(item => {
        if (favs.includes(item.key)) {
          let favItem = item.val();
          favItem.id = item.key;
          favsContent.push(favItem);
        }
      });
    }
  });
  return favsContent;
};

export const getFavouritesID = async () => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("/Users/" + userId + "/Fav");
  const result = await source.once("value");
  const favs = [];
  result.forEach(data => {
    favs.push(data.key);
  });
  return favs;
};

export const checkFav = async (elemID) => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("/Users/" + userId + "/Fav/" + elemID);
  const result = await source.once("value");
  return result.exists();
};

export const getChallenges = async () => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("Users/" + userId + "/Challenge");
  const result = await source.once("value");
  const challenges = [];
  result.forEach(data => {
    let challenges = data.val();
    challenges.id = data.key;
    challenges.push(challenges);
  });
  return challenges;
};

export const checkDay = async (challengeKey, dayChecked) => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("Users/" + userId + "/Challenge/" + challengeKey);
  const dayUpdate = {};
  dayUpdate["day" + dayChecked] = "1";
  const updateStatus = await source.update(dayUpdate);
};

export const unCheckDay = async (challengeKey, dayChecked) => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("Users/" + userId + "/Challenge/" + challengeKey);
  const dayUpdate = {};
  dayUpdate["day" + dayChecked] = "0";
  const updateStatus = await source.update(dayUpdate);
};

export const addFav = async (key, type, category) => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("/Users/" + userId + "/Fav");
  const newFav = await source.child(key).set({
    cat: category,
    type: type
  });
  return newFav;
};

export const removeFav = async key => {
  const database = firebase.database();
  const userId = firebase.auth().currentUser.uid;
  const source = database.ref("/Users/" + userId + "/Fav/" + key);
  const remove = await source.remove();
  return remove;
};
