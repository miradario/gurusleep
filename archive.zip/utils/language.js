import * as Localization from 'expo-localization'
import i18n from 'i18n-js';

i18n.fallbacks = true;
i18n.translations = {
  'ge': require('../assets/translations/DE-de.json'),
  'en': require('../assets/translations/UK-en.json')

}
//i18n.locale = Localization.locale;
//i18n.locale = 'ge';
i18n.changelocale = false;

export default i18n.translate.bind(i18n);