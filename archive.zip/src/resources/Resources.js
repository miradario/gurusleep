import * as React from "react";
import { StyleSheet, View, Text, TouchableOpacity, ActivityIndicator, StatusBar } from "react-native";
import { Button, Icon } from "native-base";
import { FontAwesome, AntDesign} from '@expo/vector-icons';
import { BaseContainer, Styles, SectionTitle, BackArrow} from "../components";
import type { ScreenProps } from "../components/Types";
import { getResources } from "../../modules/firebaseAPI"
import COLORS from "../assets/Colors"
import variables from "../../native-base-theme/variables/commonColor";
import firebase from 'firebase';

export default class Resources extends React.PureComponent<ScreenProps<>> {

  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      mounted: true,
      resources: []
    }
  }

  componentDidMount() {
    this.setState({ mounted: true });
    this.readData();
  }

  async readData() {
    let resources = [];
    getResources().then((result) => {
      result.forEach(function (data) {
        let resource = data.val();
        resource.key = data.key;
        resources.push(resource);
      })
      this.setState({
        loading: false,
        resources: resources
      })
    }).catch(error => {
      this.setState({ loading: false })
    })
  }

  getIconName(mediaType) {
    switch (mediaType) {
      case 'pdf':
        return 'pdffile1';
      case 'video':
        return 'ios-videocam';
      default:
        return 'ios-document';
    }
  }

  render(): React.Node {
    const loadingCheck = this.state.loading;
    return (
      <BaseContainer title="Resources" navigation={this.props.navigation} scrollable>
        <StatusBar backgroundColor="white" barStyle="dark-content" />
        <SectionTitle label="Workshop Resources" iconName="ios-photos"/>

        {loadingCheck ? (
          <View style={style.actIndicator} >
            <ActivityIndicator size="large" color="#ffffff" />
          </View>
        ) : null
        }
        {
          this.state.resources.map((resource) => {
            return <Item
              key={resource.key} 
              title={resource.title}
              viewable
              icon={this.getIconName(resource.type)}
              onpres={() => { this.props.navigation.navigate("Pdf", { url: resource.url, title: resource.title }) }} />
          })
        }
        {/* <Item title="One: Video Sri Sri Ravi Shankar" viewable icon="ios-videocam" onpres={() => { this.props.navigation.navigate("Player", { title: "One: Video Sri Sri Ravi Sankar", source: "firebasestorage.googleapis.com/v0/b/aprendiendofirebase-9aa43.appspot.com/o/en%2Fmeditations%2FTlexMeditationVideoIntro_480p.mp4?alt=media&token=b413540c-a208-4f0f-844c-9e097b06775e" }) }} />
      <Item title="Two: PDF " viewable icon="ios-document" onpres={() => { this.props.navigation.navigate("Pdf", { html: html1 }) }} />
      <Item title="Four: Video Sri Sri Ravi Shankar" viewable icon="ios-videocam" onpres={() => { this.props.navigation.navigate("Player", { title: "One: Video Sri Sri Ravi Sankar", source: "firebasestorage.googleapis.com/v0/b/aprendiendofirebase-9aa43.appspot.com/o/en%2Fmeditations%2FTLEX%20Desktop%20Yoga%20EN_480p.mp4?alt=media&token=dd26a1b6-ec16-4f8b-8b32-0fde76f0c8db" }) }} />
      <Item title="Three: Audio Yoga Practice" viewable icon="ios-document"
        onpres={() => {
          this.props.navigation.navigate("Audios", {
            id: "WpIAc9by5iU",
            photo: "https://i.ytimg.com/vi/o4C9MyDMb2A/maxresdefault.jpg",
            title: "Deep Relaxation",
            url: "https://firebasestorage.googleapis.com/v0/b/aprendiendofirebase-9aa43.appspot.com/o/en%2FKriya%2FTlexKriyaMusicInPrana_64kb.mp3?alt=media&token=67188163-ba1c-403d-af9f-c1ae77a8d02a",
            screen: "Audios"
          })
        }} /> */}
      </BaseContainer>
    )
  }
}

type ItemProps = {
  title: string,
  viewable?: boolean,
  icon: string
};

type ItemState = {
  viewable: boolean
};

class Item extends React.Component<ItemProps, ItemState> {

  state = {
    viewable: false
  };

  static getDerivedStateFromProps({ viewable }: ItemProps): ItemState {
    return {
      viewable: !!viewable
    };
  }

  render(): React.Node {
    const { title } = this.props;
    const { onpres } = this.props;
    const { viewable } = this.state;
    const { icon } = this.props;

    const txtStyle = viewable ? Styles.whiteText : Styles.grayText;
    return (
      <View style={[Styles.listItem, style.item]}>
        <Button
          transparent
          onPress={onpres}
          style={[Styles.center, style.button]}
        >
          <AntDesign name={icon} size={22} style={{color: COLORS.white}}/>
          {/* <Icon name={icon} style={txtStyle} /> */}
        </Button>
        <TouchableOpacity onPress={onpres} >
          <View style={style.title}>
            <Text style={[txtStyle, style.itemText]}>{title}</Text>
          </View>
        </TouchableOpacity>
        <View
          style={style.circleButton}
        >
          <FontAwesome name={'chevron-right'} size={15} style={{color: COLORS.orange}}/>
          {/* <Icon name={icon} style={txtStyle} /> */}
        </View>        
      </View>
    );
  }
}

const style = StyleSheet.create({
  item: {
    marginHorizontal: 0,
    marginLeft: 20,
    marginRight: 20,
    alignItems: 'center'
  },
  itemText: {
    alignSelf: 'stretch',
    textAlign: 'left'
  },
  button: {
    height: 75, 
    width: 35, 
    borderRadius: 0
  },
  circleButton: {
    borderRadius: 50,
    height: 30,
    width: 30,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.white
  },
  title: {
    justifyContent: "center",
    alignItems: "center",
    paddingLeft: 5,
    paddingRight: 5,
    width: 220
  },
  actIndicator: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center'
  }
});