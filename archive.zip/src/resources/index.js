// @flow
export {default as Resources} from "./Resources";
