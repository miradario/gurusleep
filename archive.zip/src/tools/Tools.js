import React, { Component } from 'react';
import { StyleSheet, View, ScrollView, Text, Image, PanResponder, Dimensions, Animated, StatusBar} from 'react-native';
import { BaseContainer, Images } from "../components";
import COLORS from "../assets/Colors";

export default class Teachers extends Component {

    render() {
        return (
            <BaseContainer title={'Tools'} scrollable  startGradient={COLORS.lightblue} endGradient={COLORS.white}>
                <StatusBar backgroundColor="white" barStyle="dark-content" />
                <View style={styles.contentWrapper}>
                    {/* <Text style={styles.mainTitle}>TOOLS</Text> */}
                    <Text style={styles.mainIntro}>
                        Tools sind Übungen und Methoden, für die man sich etwas Zeit nimmt und sich aus der Aktivität zurückzieht, um langfristig Achtsamkeit, Gesundheit und Leistungsfähigkeit zu stärken.
                    </Text>
                    <Text style={styles.subTitle}>Achtsamkeit erhöhen</Text>
                    <View style={styles.moduleWrapper}>
                        <View style={styles.moduleOrange}>
                            <Text style={styles.moduleOrangeTitle}>Körbe-Übung</Text>
                            <Image source={Images.Tools_1} style={styles.moduleOrangeImg}/>
                        </View>
                        <View style={styles.moduleBlue}>
                            <Text style={styles.moduleBlueTitle}>Nutzen:</Text>
                            <Bullet content = "Innere Ruhe"/>
                            <Bullet content = "Fokussierung"/>
                            <Text style={styles.moduleBlueTitle}>Wie:</Text>
                            <Bullet content = "Richten Sie die Aufmerksamkeit für einige Sekunden auf den Atem"/>
                            <Bullet content = "Nehmen Sie wahr, wie sich der Brustkorb hebt und senkt"/>
                            <Bullet content = "Beobachten Sie: Atme ich tief oder flach?"/>
                            <Bullet content = "Nehmen Sie bewusst ein paar lange und tiefe Atemzüge"/>                            
                        </View>
                    </View>
                    <Text style={styles.subTitle}>Verspannungen im Körper lösen und Achtsamkeit erhöhen</Text>
                    <View style={styles.moduleWrapper}>
                        <View style={styles.moduleOrange}>
                            <Text style={styles.moduleOrangeTitle}>Körbe-Übung</Text>
                            <Image source={Images.Tools_1} style={styles.moduleOrangeImg}/>
                        </View>
                        <View style={styles.moduleBlue}>
                            <Text style={styles.moduleBlueTitle}>Nutzen:</Text>
                            <Bullet content = "Flexibilität erhöhen"/>
                            <Bullet content = "Körperlichen Beschwerden vorbeugen-Rotation"/>
                            <Text style={styles.moduleBlueTitle}>Wie:</Text>
                            <Bullet content = "Kopfnicken und -kreisen"/>
                            <Bullet content = "Schulter-Rotation"/>
                            <Bullet content = "Adler im Sitzen"/>
                            <Bullet content = "Halbmond-Streckung"/>
                            <Bullet content = "Drehsitz"/>
                            <Bullet content = "Rückwärtsbeuge"/>
                            <Bullet content = "Augenübungen"/>
                        </View>
                    </View>                    
                </View>
            </BaseContainer >
        );
    }
}

class Bullet extends React.Component {

    render() {
        const { content } = this.props
        return (
            <View style={styles.bulletWrapper}>
                <Text style={styles.bullet}>{'\u2022'}</Text>
                <Text style={styles.bulletText}>{content}</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'gray',
        flex: 1
    },
    contentWrapper: {
        padding: 15,
        marginBottom: 55
    },
    mainTitle: {
        color: '#656669',
        fontSize: 20,
        marginTop: 15
    },
    mainIntro: {
        color: COLORS.gray,
        fontSize: 14,
        marginTop: 18
    },
    subTitle: {
        fontSize: 17,
        color: '#000000',
        marginTop: 30
    },
    moduleWrapper: {
        marginTop: 20
    },
    moduleBlue: {
        flex: 3,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderTopWidth: 0,
        borderLeftColor: COLORS.blue,
        borderRightColor: COLORS.blue,
        borderBottomColor: COLORS.blue,
        padding: 15,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    moduleOrange: {
        flex: 1,
        backgroundColor: COLORS.white,
        borderWidth: 1,        
        borderColor: COLORS.orange,
        padding: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    moduleOrangeImg: {
        marginTop: 10,
        width: 187,
        height: 100
    },
    moduleOrangeTitle: {
        color: COLORS.orange
    },
    moduleBlueTitle: {
        color: COLORS.gray,
        fontWeight: 'bold',
        marginTop: 15
    },
    bulletWrapper: {
        flexDirection: 'row',
        marginTop: 12
    },
    bullet: {
        color: COLORS.gray,
        marginRight: 5
    },
    bulletText: {
        color: COLORS.gray,
        marginRight: 5
    }
});
