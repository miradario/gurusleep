import * as React from "react";
import {
  View,
  Image,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList
} from "react-native";
import {
  Button,
  Header,
  Left,
  Right,
  Body,
  Icon,
  Title,
  Text,
  Content,
  Label
} from "native-base";
import { Constants } from "expo";
import {
  Container,
  Images,
  Field,
  Styles,
  SingleChoice,
  WindowDimensions,
  Small
} from "../components";
import type { ScreenProps } from "../components/Types";
import { LinearGradient } from "expo-linear-gradient";
import { HomeContainer } from "../components";
import COLORS from "../assets/Colors";
import variables from "../../native-base-theme/variables/commonColor";
import * as FirebaseAPI from "../../modules/firebaseAPI.js";
import firebase from "firebase";
import translate from "../../utils/language";
import i18n from "i18n-js";

const ger = require("../assets/flags/germany.png");
const eng = require("../assets/flags/england.png");

export default class SignUp extends React.Component<ScreenProps<>> {
  state = {
    name: "",
    user: "",
    password: "",
    company: "",
    language: "EN",
    data: [
      { id: "en", image: eng, toggle: false },
      { id: "ge", image: ger, toggle: false }
    ]
  };
  name: TextInput;
  username: TextInput;
  password: TextInput;
  company: TextInput;

  setnameRef = (input: TextInput) => (this.name = input._root);
  goToname = () => this.name.focus();
  setUsernameRef = (input: TextInput) => (this.username = input._root);
  goToUsername = () => this.username.focus();
  setPasswordRef = (input: TextInput) => (this.password = input._root);
  goToPassword = () => this.password.focus();
  back = () => this.props.navigation.navigate("Login");
  //   signIn = () => this.props.navigation.navigate("Walkthrough")

  componentDidMount() {
    this.watchAuthState(this.props.navigation);
  }

  watchAuthState(navigation) {
    firebase.auth().onAuthStateChanged(function (user) {
      if (user) {
        navigation.navigate("Walkthrough");
      }
    });
  }

  onPressed = imageID => {
    const { data } = this.state;
    data.forEach(elem => {
      elem.toggle = false;
      if (elem.id == imageID) {
        elem.toggle = true;
      }
    });

    this.setState({ data: data });
    this.setState({ updateSelected: !this.state.updateSelected });
    i18n.locale = imageID;
    this.state.language = imageID;
  };

  renderItem = data => (
    <FlagImage
      id={data.id}
      onPressItem={this.onPressed}
      image={data.image}
      active={data.toggle}
    />
  );

  createUser() {
    FirebaseAPI.createUser(this.state.user, this.state.password);
  }

  render(): React.Node {
    return (
      <HomeContainer bottom={10}>
        {/* <Image source={Images.header} style={style.header} /> */}
        <LinearGradient
          colors={[COLORS.blue, COLORS.lightblue]}
          style={{
            flex: 1,
            alignItems: "center",
            paddingLeft: 15,
            paddingRight: 15
          }}
          start={[1, 0]}
          end={[1, 1]}
        >
          <Content style={Styles.flexGrow}>
            <View style={style.form}>
              <Text style={style.title}>
                <Text style={style.title}>Signup</Text>
                <Text style={style.dot}>.</Text>
              </Text>
              <View style={style.loginArea}>
                <View style={style.inputContainer}>
                  <Field
                    label={translate("name")}
                    value={this.state.name}
                    onChangeText={text => this.setState({ name: text })}
                    onSubmitEditing={this.goToUsername}
                    returnKeyType="next"
                    displayIcon
                    iconName="md-person"
                    labelColor={COLORS.gray}
                    iconColor={COLORS.orange}
                  />
                  <Field
                    label={translate("email")}
                    value={this.state.user}
                    onChangeText={text => this.setState({ user: text })}
                    onSubmitEditing={this.goToUsername}
                    returnKeyType="next"
                    displayIcon
                    iconName="md-mail"
                    labelColor={COLORS.gray}
                    iconColor={COLORS.orange}
                  />
                  <Field
                    label={translate("password")}
                    secureTextEntry
                    textInputRef={this.setPasswordRef}
                    onChangeText={text => this.setState({ password: text })}
                    value={this.state.password}
                    onSubmitEditing={() => this.createUser()}
                    returnKeyType="go"
                    displayIcon
                    iconName="md-lock"
                    labelColor={COLORS.gray}
                    iconColor={COLORS.orange}
                  />
                  <Field
                    label={translate("company")}
                    textInputRef={this.company}
                    displayIcon
                    iconColor={COLORS.white}
                    value={this.state.company}
                    labelColor={COLORS.white}
                    onChangeText={text => this.setState({ company: text })}
                    iconName="md-briefcase"
                    labelColor={COLORS.gray}
                    iconColor={COLORS.orange}
                    last
                  />
                  <Label
                    style={[
                      style.fieldLabel,
                      { marginTop: 20 }
                    ]}
                  >
                    {translate("language")}
                  </Label>
                  <View style={{marginLeft: 16, marginBottom: 10}}>
                    <FlatList
                      refresh={this.state.updateSelected}
                      horizontal
                      keyExtractor={item => item.id.toString()}
                      data={this.state.data}
                      renderItem={({ item }) => this.renderItem(item)}
                    />
                  </View>



                </View>
                <View>
                  <Button transparent full onPress={this.back}>
                    <Small style={style.signInText}>
                      Already have an account? <Small style={[style.signInText, {textDecorationLine:'underline'}]}>Login</Small>
                    </Small>
                  </Button>
                </View>
              </View>
              <View style={style.loginContainer}>
                <TouchableOpacity
                  style={style.loginButton}
                  onPress={() => this.createUser()}
                >
                  <Text style={style.loginText}>Sign Up</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Content>
        </LinearGradient>
      </HomeContainer>
    );
  }
}


class FlagImage extends React.PureComponent {
  _onPress = () => {
    this.props.onPressItem(this.props.id);
  };

  render() {
    const { active } = this.props;
    const colorsel = active ? 1 : 0;

    return (
      <View style={style.item}>
        <TouchableOpacity onPress={this._onPress}>
          <Image
            style={[style.image, { borderWidth: colorsel }]}
            resizeMode="cover"
            source={this.props.image}
          ></Image>

          {/*  <Text>{active ? 'Activo' : 'Inactivo'}</Text> */}
        </TouchableOpacity>
      </View>
    );
  }
}



const style = StyleSheet.create({
  img: {
    ...StyleSheet.absoluteFillObject,
    width: WindowDimensions.width,
    height: WindowDimensions.height
    //top: Constants.statusBarHeight
  },
  header: {
    width: WindowDimensions.width,
    height: (WindowDimensions.width / 750) * 150,
    resizeMode: "contain",
    flex: 1,
    position: "absolute",
    top: 0,
    zIndex: 1000
  },
  row: {
    flexDirection: "row"
  },
  form: {
    paddingTop: 15
  },
  btn: {
    flex: 1,
    margin: 0,
    borderRadius: 0,
    justifyContent: "center",
    alignItems: "center",
    height: 125,
    flexDirection: "column"
  },
  icon: {
    color: "white",
    marginRight: 5
  },
  title: {
    color: "white",
    textAlign: "left",
    fontSize: 50,
    fontWeight: "bold",
    fontFamily: "Avenir-Black"
  },
  dot: {
    fontSize: 70,
    color: "#f26f21"
  },
  loginButton: {
    marginTop: 20,
    paddingTop: 15,
    paddingBottom: 15,
    backgroundColor: "#f26f21",
    borderRadius: 25,
    width: 200,
    alignContent: "center"
  },
  loginContainer: {
    width: "100%",
    justifyContent: "center",
    alignItems: "center"
  },
  loginText: {
    textAlign: "center"
  },
  signInText: {
    color: COLORS.gray
  },
  inputContainer: {
    width: 300,
    backgroundColor: COLORS.lightblue,
    borderRadius: 15,
    marginTop: 25
  },
  loginArea: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    marginTop: -11
  },
  item: {
    margin: 1,
    width: 70
  },
  fieldLabel: {
    color: COLORS.gray,
    fontSize: 14,
    marginLeft: 16,
    marginBottom: 12
  },
  image: {
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: 50,
    height: 50,
    borderColor: "white"
  },
});
