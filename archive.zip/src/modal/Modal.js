import React, { Component } from 'react';
import { StyleSheet, View, Text, Button} from 'react-native';
import COLORS from "../assets/Colors";

export default class Modal extends Component {

  render() {

    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ fontSize: 30 }}>Welcome to TlexApp</Text>
        <Button onPress={() => this.props.navigation.goBack()} title="Begin!" />
      </View>
    )
  }
}