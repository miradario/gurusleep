import React, { Component } from 'react';
import { StyleSheet, View, Text, Image, StatusBar, Animated, FlatList, TouchableOpacity, Easing, Platform} from 'react-native';
import { Video } from 'expo-av';
import Images from "../components/images";
import { Ionicons } from '@expo/vector-icons';
import DraggableBackdrop from 'react-native-draggable-backdrop';
import { HomeContainer, FavButton } from '../components';
import WindowDimensions from "../components/WindowDimensions";
import { LinearGradient } from 'expo-linear-gradient';
import COLORS from "../assets/Colors";
import BottomUpPanel from "../components/BottomPanel/index";
import { getContent, getFavsContent, removeFav } from "../../modules/firebaseAPI";
import { Constants } from "expo";
import { DangerZone } from 'expo';
import translate from '../../utils/language';
import * as Animatable from 'react-native-animatable';
import { PanGestureHandler } from 'react-native-gesture-handler'

const { Lottie } = DangerZone;

const med1 = require("../assets/thumbs/focus_thum.jpg");
const med2 = require("../assets/thumbs/harmony_thum.jpg");
const med3 = require("../assets/thumbs/inner_contentment_thum.jpg");
const med4 = require("../assets/thumbs/nothing_thum.jpg");
const med5 = require("../assets/thumbs/powernap_thum.jpg");

const urlimg = 'https://gesundes-und-achtsames-fuehren.de/assets/img/';

export default class Home extends Component {

  constructor() {
    super();
    this.state = {
      animation: new Animated.Value(1),
      showCover: true,
      panelHeight: 185,
      dashMargin: 0,
      headerWidth: 0,
      headerHeight: 0,
      arrowVisible: true
    }
  }

  componentDidMount() {
    this.removeCover();
    this.focusListener = this.props.navigation.addListener(
      "didFocus",
      () => {
        this.setContentData();
      });
  }

  async setContentData() {
    const dataSetFavs = await getFavsContent();
    this.setState({ contentFavs: dataSetFavs, contentReady: true });
     const dataSetYoga = await getContent('DesktopYoga');
     this.setState({ contentYoga: dataSetYoga, contentReady: true });
     const dataSetMP = await getContent('Mindpause');
     this.setState({ contentMindPause: dataSetMP, contentReady: true });
  }

  panelOpened = () => {
    let extraMargin = (Platform.OS == 'ios') ? 0.3931 * WindowDimensions.height - 180.2 : 55
    let panelHeight = (Platform.OS == 'ios') ? 260 : 265
    let openMargin = extraMargin
    this.setState({ panelHeight: panelHeight, dashMargin: openMargin, arrowVisible: false})
  }

  panelClosed = () => {
    this.setState({ panelHeight: 220, dashMargin: 0, arrowVisible: true})
  }

  removeCover = () => {
    setTimeout(() => {
      Animated.timing(this.state.animation, {
        toValue: 0,
        timing: 400
      }).start(() => this.setState({ showCover: false }))
      this.props.navigation.navigate('ModalScreen')
    }, 4700)
  }

  onMountain = (key, title) => {
    this.props.navigation.navigate("Mountain", {
      pkey: key,
      title: title
    })
  }

  onNewChallenge = () => {
    this.props.navigation.navigate("Create")
  }

  handleHeartClick = async (key) => {
    await removeFav(key)
  }

  getHeaderWidth(event) {
    let headerHeight = (event.nativeEvent.layout.width / 750) * 150
    this.setState({
      headerWidth: event.nativeEvent.layout.width,
      headerHeight: headerHeight
    })
  }

  renderBottomUpPanelContent = () =>
    <View style={{ height: WindowDimensions.height }}>
      <LinearGradient
        colors={[COLORS.blue, COLORS.blue]}
        style={{ flex: 1, alignItems: 'center', paddingLeft: 15, paddingRight: 15 }}
        start={[1, 0]}
        end={[1, 1]}>
        <View style={styles.meditationsArea}>
          <MeditationRow meditations={this.state.contentFavs} navigation={this.props.navigation} title="Favourites" icon="ios-heart" handleHeartClick={this.handleHeartClick} />
          <MeditationRow meditations={this.state.contentMindPause} navigation={this.props.navigation} title="Mindfullness" icon="md-person" handleHeartClick="0"/> 
          <MeditationRow meditations={this.state.contentYoga} navigation={this.props.navigation}  title="Desktop Yoga" icon="md-pulse" handleHeartClick="0"/> 
        </View>
      </LinearGradient>
    </View>

  renderBottomUpPanelIcon = () =>
    <Ionicons name={"ios-arrow-up"} style={{ color: "white" }} size={30} />

  render() {
    const coverOpacity = {
      opacity: this.state.animation
    }
    const { navigation } = this.props;
    const { headerHeight } = this.state

    return (
      <HomeContainer {...{ navigation }}>
        <StatusBar backgroundColor="white" barStyle="dark-content" />
        <View style={styles.tlexLogoWrapper}><Image source={Images.tlex_white} style={styles.tlexLogo}></Image></View>
        {
          this.state.showCover &&
          (<LoadingCover coverOpacity={coverOpacity} />)
        }
        {/* < Image onLayout={(event) => this.getHeaderWidth(event)} source={Images.header} style={[styles.header, { height: this.state.headerHeight }]} /> */}
        <View style={styles.videoContainer}>
          <Video
            source={{ uri: "https://www.gesundes-und-achtsames-fuehren.de/assets/video/bridge.mp4" }}
            style={styles.backgroundVideo}
            rate={1}
            shouldPlay={true}
            isLooping={true}
            volume={1}
            muted={true}
            resizeMode="cover"
          />
        </View>
        <BouncingArrow triggerAnimation={!this.state.showCover} showArrow={this.state.arrowVisible} />
        <BottomUpPanel
          content={this.renderBottomUpPanelContent}
          icon={this.renderBottomUpPanelIcon}
          topEnd={70}
          startHeight={this.state.panelHeight}
          dashMargin={this.state.dashMargin}
          panelOpened={this.panelOpened}
          panelClosed={this.panelClosed}
          triggerAnimation={!this.state.showCover}
          onMountain={this.onMountain}
          onNewChallenge={this.onNewChallenge}
          headerText={"List of items"}
          headerTextStyle={{
            color: "white",
            fontSize: 15
          }}
          bottomUpSlideBtn={{
            //borderTopLeftRadius: 30,
            //borderTopRightRadius: 30,
            display: 'flex',
            alignSelf: 'flex-start',
            //backgroundColor: COLORS.blue,
            //padding: 15
          }}>
        </BottomUpPanel>
      </HomeContainer >
    );
  }
}

class LoadingCover extends Component {
  componentDidMount() {
    //this.animation.play();
  }

  render() {
    const { coverOpacity } = this.props
    return (
      <Animated.View style={[styles.loadingCover, coverOpacity]} >
        <LinearGradient
          colors={[COLORS.blue, COLORS.white]}
          style={styles.loadingGradient}
          start={[1, 0]}
          end={[1, 1]}>
          <Animatable.Text animation="pulse" iterationCount="infinite" easing="ease-out" style={styles.loadingText}>{translate("takeadeep")}</Animatable.Text>
          {/* <Lottie
            ref={animation => {
              this.animation = animation;
            }}
            style={{
              width: 300,
              height: 300,
            }}
            source={require('../../assets/animations/water.json')}
          /> */}
        </LinearGradient>
      </Animated.View>
    )
  }
}

class BouncingArrow extends React.PureComponent {

  constructor() {
    super()
    this.arrowValue = new Animated.Value(0)
    //this.fadeValue = new Animated.Value(1)
  }

  componentDidUpdate(prevProps, prevSate, snapshot) {
    if (prevProps.triggerAnimation !== this.props.triggerAnimation) {
      if (this.props.triggerAnimation) {
        setTimeout(() => {
          this.animateArrow()
        }, 2500)
      }
    }
  }

  fadeArrow() {
    this.fadeValue.setValue(1);
    Animated.timing(
      this.fadeValue,
      {
        toValue: 0,
        duration: 400,
        easing: Easing.linear
      }
    ).start();
    console.log(this.fadeValue)
  }

  animateArrow() {
    this.arrowValue.setValue(0);
    Animated.loop(
      Animated.timing(
        this.arrowValue,
        {
          toValue: 1,
          duration: 700,
          easing: Easing.ease
        }
      ),
      { iterations: 3 }
    ).start(
      // () => this.fadeArrow()
      );
  }

  render() {

    const arrowBottom = this.arrowValue.interpolate({
      inputRange: [0, 0.5, 1],
      outputRange: [190, 195, 190]
    })
    if(this.props.showArrow) {
      return (
        <Animated.View style={[styles.bounceArrow, { bottom: arrowBottom, opacity: this.fadeValue,  }]}>
          <Ionicons name={"ios-arrow-up"} style={{ color: "white" }} size={30} />
        </Animated.View>
      )
    } else {
      return null
    }
  }
}

class MeditationThumb extends React.PureComponent {

  state = {
    itemVisible: true
  }

  onThumbClick() {
    if (this.props.type == 'audio') {
      this.props.navigation.navigate("Audios", {
        category: 'Meditation',
        Description: this.props.Description,
        duration: this.props.duration,
        key: this.props.id,
        url: this.props.url,
        title: this.props.title,
        photo: urlimg + this.props.image
      })
    } else {
      this.props.navigation.navigate("Player", {
        category: 'Meditation',
        Description: this.props.Description,
        duration: this.props.duration,
        key: this.props.id,
        url: this.props.url,
        title: this.props.title,
        photo: urlimg + this.props.image
      })
    }
  }  

  onFavClick = () => {
    this.props.handleHeartClick(this.props.id)
    this.setState({ itemVisible: false })
  }

  render() {
    let heartColor = COLORS.orange
    return (
      this.state.itemVisible &&
      <View style={styles.meditationThumb}>
        <TouchableOpacity activeOpacity={0.5} onPress=
          {() => this.onThumbClick()}>
          <Image
            style={[styles.meditationThumbImage]}
            resizeMode="cover"
            source={{ uri: urlimg + this.props.image }}
          ></Image>
          {this.props.handleHeartClick !="0" ? (
          <FavButton handleFavPress={() => this.onFavClick()} heartColor={heartColor}/>
           ) : (
            <View/>
            )}
          <View style={styles.thumbTitle}></View>
          <Text style={styles.thumbTitleText}>{this.props.title}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

class MeditationRow extends React.PureComponent {

  renderItem = (data) => 
    <MeditationThumb 
      Description={data.Description} 
      duration={data.duration} 
      navigation={this.props.navigation} 
      key={data.id} 
      id={data.id} 
      title={data.title} 
      image={data.thumbnail} 
      active={data.toggle} 
      handleHeartClick={this.props.handleHeartClick}
      type={data.type} />

  render() {
    const { meditations, title, icon } = this.props
    return (
      <View style={styles.meditationRowWrapper}>

        <View style={styles.meditationRow}>
          <Ionicons name={icon} style={{ color: COLORS.white }} size={30} />
          <Text style={styles.meditationRowTitle}>{title}</Text>
        </View>
        <FlatList
          // refresh={this.state.updateSelected}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={item => item.id.toString()}
          data={meditations}
          renderItem={({ item }) => this.renderItem(item)} />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  videoContainer: {
    flex: 0.81,
    backgroundColor: 'transparent'
  },
  loginContainer: {
    alignItems: 'center',
    flexGrow: 0.95,
    justifyContent: 'center',
  },
  backgroundVideo: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0
  },
  header: {
    width: WindowDimensions.width,
    resizeMode: 'contain',
    flex: 1,
    position: "absolute",
    top: 0,
    zIndex: 1000
  },
  dashboard: {
    flex: 0.25,
    backgroundColor: 'red',
    borderRadius: 30,
    marginTop: -25
  },
  loadingCover: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 10000000,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingGradient: {
    paddingTop: WindowDimensions.height / 5,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    alignSelf: 'stretch'
  },
  loadingText: {
    color: COLORS.white,
    fontSize: 15
  },
  meditationsArea: {
    marginTop: 0,
    flex: 1
  },
  meditationThumb: {
    marginRight: 15,
  },
  meditationThumbImage: {
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: 130,
    height: 140,
    opacity: 0.9,
    borderRadius: 15,
  },
  thumbTitle: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 25,
    backgroundColor: '#000000',
    opacity: 0.3,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15
  },
  thumbTitleText: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 5,
    fontSize: 12,
    textAlign: "center",
    color: COLORS.white
  },
  meditationRow: {
    flexDirection: "row",
    alignItems: "center",
    width: 300,
    marginBottom: 15
  },
  meditationRowWrapper: {
    height: 205,
    marginBottom: 20
  },
  meditationRowTitle: {
    color: COLORS.white,
    fontSize: 16,
    marginLeft: 10,
    fontWeight: 'bold'
  },
  btnFavWrapper: {
    position: 'absolute',
    top: 7,
    right: 7
  },
  tlexLogoWrapper: {
    position: 'absolute',
    top: 7,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 1000
  },
  tlexLogo: {
    width: 70,
    height: 50,
    resizeMode: 'contain'
  },
  bounceArrow: {
    position: 'absolute',
    zIndex: 3000,
    left: WindowDimensions.width / 2 - 17
  }

});