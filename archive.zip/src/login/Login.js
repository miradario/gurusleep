// @flow
import * as React from "react";
import { StyleSheet, Image, View, TextInput, SafeAreaView, TouchableOpacity, ActivityIndicator } from "react-native";
import { H1, Button, Text, Content, Icon } from "native-base";
import { Constants } from "expo";
import Mark from "./Mark";
import { Images, WindowDimensions, Field, Small, Styles } from "../components";
import { LinearGradient } from 'expo-linear-gradient';
import { HomeContainer } from '../components';
import COLORS from "../assets/Colors";
import { AnimatedView } from "../components/Animations";
import type { ScreenProps } from "../components/Types";
import variables from "../../native-base-theme/variables/commonColor";
import firebase from 'firebase';
import * as FirebaseAPI from '../../modules/firebaseAPI.js';

export default class Login extends React.Component<ScreenProps<>> {

    constructor() {
        super();
        _isMounted = false;
        this.state = {
            email: "",
            password: "",
            verifying: false
        }
    }

    componentDidMount() {
        this._isMounted = true;
        this.watchAuthState(this.props.navigation)
    }

    componentWillUnmount(){
        this._isMounted = false;
    }

    watchAuthState(navigation) {
        firebase.auth().onAuthStateChanged(function (user) {
            if (user) {
                navigation.navigate('Main');
            }
        });
    }

    async signIn() {
        this.setState({ verifying: true })
        await FirebaseAPI.signInUser(this.state.email, this.state.password)
        if(this._isMounted){this.setState({ verifying: false })};
    }

    password: TextInput;

    setPasswordRef = (input: TextInput) => this.password = input._root
    goToPassword = () => this.password.focus()
    /* signIn = () => this.props.navigation.navigate("Walkthrough") */
    signUp = () => this.props.navigation.navigate("SignUp")

    render(): React.Node {
        return (
            <HomeContainer>
                {/* <Image source={Images.header} style={styles.header} /> */}
                <View style={styles.container}>
                    <LinearGradient
                        colors={[COLORS.blue, COLORS.white]}
                        style={{ flex: 1, alignItems: 'center', paddingLeft: 15, paddingRight: 15 }}
                        start={[1, 0]}
                        end={[1, 1]}>
                        <SafeAreaView style={StyleSheet.absoluteFill}>
                            <Content style={[StyleSheet.absoluteFill, styles.content]}>
                                <AnimatedView style={styles.innerContent}>
                                    <Text style={styles.title}>
                                        <Text style={styles.title}>Login</Text>
                                        <Text style={styles.dot}>.</Text>
                                    </Text>
                                    <View style={styles.loginArea}>
                                        <View style={styles.inputContainer}>
                                            <Field
                                                label="Username"
                                                autoCapitalize="none"
                                                returnKeyType="next"
                                                value={this.state.email}
                                                onChangeText={(text) => this.setState({ email: text })}
                                                onSubmitEditing={this.goToPassword}
                                                displayIcon
                                                iconName="md-person"
                                                labelColor={COLORS.gray}
                                                iconColor={COLORS.orange}
                                            />
                                            <Field
                                                label="Password"
                                                secureTextEntry
                                                autoCapitalize="none"
                                                returnKeyType="go"
                                                onChangeText={(text) => this.setState({ password: text })}
                                                value={this.state.password}
                                                textInputRef={this.setPasswordRef}
                                                onSubmitEditing={() => this.signIn()}
                                                last
                                                displayIcon
                                                iconName="md-lock"
                                                labelColor={COLORS.gray}
                                                iconColor={COLORS.orange}
                                            />
                                        </View>
                                    </View>
                                    <View>
                                        <View>
                                            <Button transparent full onPress={this.signUp}>
                                                <Small style={styles.signInText}>Don&apos;t have an account? <Small style={[styles.signInText, {textDecorationLine:'underline'}]}>Sign Up</Small></Small>
                                            </Button>
                                        </View>
                                        <View style={styles.loginContainer}>
                                            {this.state.verifying ? (
                                                <ActivityIndicator color={'white'}/>
                                            ) :
                                                (
                                                    <TouchableOpacity style={styles.loginButton} onPress={() => this.signIn()}>
                                                        <Text style={styles.loginText}>Sign In</Text>
                                                    </TouchableOpacity>
                                                )}
                                        </View>
                                    </View>
                                </AnimatedView>
                            </Content>
                        </SafeAreaView>
                    </LinearGradient>
                </View>
            </HomeContainer>

        );
    }
}

const { height, width } = WindowDimensions;
const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    header: {
        width: WindowDimensions.width,
        height: WindowDimensions.width / 750 * 150,
        resizeMode: 'contain',
        flex: 1,
        position: "absolute",
        top: 0,
        zIndex: 1000
    },
    content: {
        flex: 1
    },
    innerContent: {
        paddingTop: 110,
        height: height - Constants.statusBarHeight,
    },
    title: {
        color: "white",
        textAlign: "left",
        fontSize: 50,
        paddingLeft: (WindowDimensions.width-300)/2 - 12,
        fontWeight: "bold",
        fontFamily: "Avenir-Black"
    },
    dot: {
        fontSize: 70,
        color: '#f26f21'
    },
    loginButton: {
        marginTop: 20,
        paddingTop: 15,
        paddingBottom: 15,
        backgroundColor: COLORS.orange,
        borderRadius: 25,
        width: 200,
        alignContent: 'center'
    },
    loginContainer: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    loginText: {
        textAlign: 'center',
        color: COLORS.white,
        fontWeight: 'bold'
    },
    signInText: {
        textAlign: 'right',
        color: COLORS.gray
    },
    inputContainer: {
        width: 300,
        backgroundColor: COLORS.lightblue,
        borderRadius: 15,
        marginTop: 25,
        borderWidth: 1,
        borderColor: COLORS.white
    },
    loginArea: {
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: -11
    }
});