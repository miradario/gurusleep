// @flow
export {default as Splash} from "./Splash";
