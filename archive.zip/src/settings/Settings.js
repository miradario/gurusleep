// @flow
import * as React from "react";
import {
  View,
  Dimensions,
  Image,
  StyleSheet,
  InteractionManager,
  Picker,
  StatusBar,
  FlatList,
  TouchableOpacity,
  AsyncStorage
} from "react-native";
import { Text, Icon, Button, Label } from "native-base";
import { BaseContainer, Images, Field, SingleChoice } from "../components";
import type { ScreenProps } from "../components/Types";

import variables from "../../native-base-theme/variables/commonColor";
import firebase from "firebase";
import * as FirebaseAPI from "../../modules/firebaseAPI.js";
import ButtonGD from "../components/ButtonGD";
import COLORS from "../assets/Colors";
import i18n from "i18n-js";
import translate from '../../utils/language';

const ger = require("../assets/flags/germany.png");
const eng = require("../assets/flags/england.png");

export default class Settings extends React.PureComponent<ScreenProps<>> {
  constructor(props) {
    super(props);
    this.state = { firstname: "", password: "", company: "", language: "" };
    this.database = firebase.database();
    this.state.userId = firebase.auth().currentUser.uid;
    this.state.email = firebase.auth().currentUser.email;
   

    this.state.data = [
      { id: "en", image: eng, toggle: false },
      { id: "ge", image: ger, toggle: false }
    ];
  }

  onPressed_ini = () => {
    const { data } = this.state;
    data.forEach(elem => {
      elem.toggle = false;
      if (elem.id == this.state.language) {
        elem.toggle = true;
      }
    });

    this.setState({ data: data });
    this.setState({ updateSelected: !this.state.updateSelected });
  };

  async componentDidMount() {
    const dataObj = await FirebaseAPI.getUser();

    
    this.state.email = firebase.auth().currentUser.email;
    this.setState({ firstname: dataObj.displayName });
    this.setState({ company: dataObj.company });
    this.setState({ language: dataObj.language });
    this.onPressed_ini();
  }

  logout(navigation) {
    FirebaseAPI.logoutUser();
    InteractionManager.runAfterInteractions(() => {
      this.props.navigation.navigate("Login");
    });
  }

  UpdateUser(navigation) {
 
    this._storeData();
   
    i18n.changelocale = true;

    i18n.locale = this.state.language;

    FirebaseAPI.UpdateUser(
      this.state.userId,
      this.state.firstname,
      this.state.email,
      this.state.password,
      this.state.company,
      this.state.language
    );

    InteractionManager.runAfterInteractions(() => {
      this.props.navigation.navigate("Home");
    });
  }

_storeData = async () => {
  try {
    await AsyncStorage.setItem('language', this.state.language);
   
  } catch (error) {
    // Error saving data
  } 
};

  onPressed = imageID => {
    const { data } = this.state;
    data.forEach(elem => {
      elem.toggle = false;
      if (elem.id == imageID) {
        elem.toggle = true;
      }
    });

    this.setState({ data: data });
    this.setState({ updateSelected: !this.state.updateSelected });
    i18n.locale = imageID;
    this.state.language = imageID;


  
  };

  renderItem = data => (
    <FlagImage
      id={data.id}
      onPressItem={this.onPressed}
      image={data.image}
      active={data.toggle}
    />
  );

  render(): React.Node {
    return (
      <BaseContainer
        title="Settings"
        navigation={this.props.navigation}
        scrollable
        backBtn
      >
        <StatusBar backgroundColor="white" barStyle="dark-content" />

        <Field
          label={translate("name")}
          value={this.state.firstname}
          onChangeText={text => this.setState({ firstname: text })}
          onSubmitEditing={this.goToUsername}
          returnKeyType="next"
          displayIcon
          iconName="md-person"
          labelColor={COLORS.white}
          iconColor={COLORS.white}
         
          inverse
        />
        <Field
          label={translate("email")}
          displayIcon
          iconName="md-mail"
          iconColor={COLORS.white}
          labelColor={COLORS.white}
          value={this.state.email}
          onChangeText={text => this.setState({ email: text })}
          inverse
        />

        <Field
          label={translate("company")}
          displayIcon
          iconName="md-business"
          iconColor={COLORS.white}
          value={this.state.company}
          labelColor={COLORS.white}
          onChangeText={text => this.setState({ company: text })}
         
          inverse
        />
        <Label style={[style.fieldLabel, { marginTop: 20, marginBottom: 20 }]}>
          {translate("language")}
        </Label>
        <FlatList
          refresh={this.state.updateSelected}
          horizontal
          keyExtractor={item => item.id.toString()}
          data={this.state.data}
          renderItem={({ item }) => this.renderItem(item)}
        />

        <ButtonGD
          title={translate("update")}
          onpress={() => this.UpdateUser(this.props.navigation)}
        />

        <View style={style.logoutContainer}>
          <Button
            transparent
            block
            onPress={() => {
              this.logout(this.props.navigation);
            }}
          >
            <Text>{translate("logout")}</Text>
          </Button>
        </View>
      </BaseContainer>
    );
  }
}

class FlagImage extends React.PureComponent {
  _onPress = () => {
    this.props.onPressItem(this.props.id);
  };

  render() {
    const { active } = this.props;
    const colorsel = active ? 1 : 0;

    return (
      <View style={style.item}>
        <TouchableOpacity onPress={this._onPress}>
          <Image
            style={[style.image, { borderWidth: colorsel }]}
            resizeMode="cover"
            source={this.props.image}
          ></Image>

          {/*  <Text>{active ? 'Activo' : 'Inactivo'}</Text> */}
        </TouchableOpacity>
      </View>
    );
  }
}

const { width } = Dimensions.get("window");
const style = StyleSheet.create({
  mainContainer: {
    paddingTop: 20,
    flex: 1
  },
  img: {
    width,
    height: width * (500 / 750)
  },
  fieldLabel: {
    color: "white",
    marginRight: 10
  },
  item: {
    margin: 1,
    width: 70
  },
  image: {
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: 50,
    height: 50,

    borderColor: "white"
  },
  add: {
    backgroundColor: "white",
    height: 50,
    width: 50,
    borderRadius: 25,
    position: "absolute",
    bottom: variables.contentPadding,
    left: variables.contentPadding,
    alignItems: "center",
    justifyContent: "center"
  },
  section: {
    padding: variables.contentPadding * 2,
    borderBottomWidth: variables.borderWidth,
    borderColor: variables.listBorderColor
  },
  logoutContainer: {
    flex: 1,
    justifyContent: "flex-end",
    marginBottom: 80
  }
});
