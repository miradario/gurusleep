// @flow
export {default as Contact} from "./Contact";
