import React, { Component } from 'react';
import { StyleSheet, View, ScrollView, Text, Image, PanResponder, Dimensions, Animated, StatusBar} from 'react-native';
import { BaseContainer, Images } from "../components";
import COLORS from "../assets/Colors";

export default class Teachers extends Component {

    render() {
        return (
            <BaseContainer title={'Micromoments'} scrollable  startGradient={COLORS.lightblue} endGradient={COLORS.white}>
                <StatusBar backgroundColor="white" barStyle="dark-content" />
                <View style={styles.contentWrapper}>
                    <Text style={styles.mainTitle}>MIKRO-MOMENTE FÜR MAKRO-EFFEKTE</Text>
                    <Text style={styles.mainIntro}>
                        Mikro-Momente sind kurze Interventionen, die im Laufe des Tages in bestimmten Situationen eingesetzt werden können, um Leistungsfähigkeit zu erhöhen, Gesundheit und Wohlbefinden zu stärken und Führung zu verbessern.
                    </Text>
                    <Text style={styles.subTitle}>Herausfordernde Situationen meistern</Text>
                    <View style={styles.moduleWrapper}>
                        <View style={styles.moduleOrange}>
                            <Text style={styles.moduleOrangeTitle}>Atem-Anker in Stress- situationen (10 Sek.)</Text>
                            <Image source={Images.MT1} style={styles.moduleOrangeImg}/>
                        </View>
                        <View style={styles.moduleWhite}>
                            <Text style={styles.moduleWhiteTitle}>Nutzen:</Text>
                            <Bullet content = "Innere Ruhe"/>
                            <Bullet content = "Fokussierung"/>
                            <Text style={styles.moduleWhiteTitle}>Wie:</Text>
                            <Bullet content = "Richten Sie die Aufmerksamkeit für einige Sekunden auf den Atem"/>
                            <Bullet content = "Nehmen Sie wahr, wie sich der Brustkorb hebt und senkt"/>
                            <Bullet content = "Beobachten Sie: Atme ich tief oder flach?"/>
                            <Bullet content = "Nehmen Sie bewusst ein paar lange und tiefe Atemzüge"/>                            
                        </View>
                    </View>
                </View>
            </BaseContainer >
        );
    }
}

class Bullet extends React.Component {

    render() {
        const { content } = this.props
        return (
            <View style={styles.bulletWrapper}>
                <Text style={styles.bullet}>{'\u2022'}</Text>
                <Text style={styles.bulletText}>{content}</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'gray',
        flex: 1
    },
    contentWrapper: {
        padding: 15,
        marginBottom: 55
    },
    mainTitle: {
        color: '#656669',
        fontSize: 20,
        marginTop: 15
    },
    mainIntro: {
        color: COLORS.gray,
        fontSize: 14,
        marginTop: 18
    },
    subTitle: {
        fontSize: 17,
        color: '#000000',
        marginTop: 30
    },
    moduleWrapper: {
        flexDirection: 'row', 
        marginTop: 20
    },
    moduleWhite: {
        flex: 3,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderLeftWidth: 0,
        borderTopColor: COLORS.blue,
        borderRightColor: COLORS.blue,
        borderBottomColor: COLORS.blue,
        padding: 15,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    moduleOrange: {
        flex: 1,
        backgroundColor: COLORS.orange,
        borderWidth: 1,
        borderRightWidth: 0,
        borderTopColor: COLORS.white,
        borderLeftColor: COLORS.white,
        borderBottomColor: COLORS.white,
        padding: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    moduleOrangeImg: {
        marginTop: 20
    },
    moduleOrangeTitle: {
        color: COLORS.white
    },
    moduleWhiteTitle: {
        color: COLORS.gray,
        fontWeight: 'bold',
        marginTop: 15
    },
    bulletWrapper: {
        flexDirection: 'row',
        marginTop: 12
    },
    bullet: {
        color: COLORS.gray,
        marginRight: 5
    },
    bulletText: {
        color: COLORS.gray,
        marginRight: 5
    }
});
