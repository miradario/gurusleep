import * as React from "react";
import { BaseContainer } from "../components";
import { StatusBar } from "react-native";
import ListMeditate from "../components/ListMeditate";


export default class Work extends React.Component<ScreenProps<>> {

  constructor() {
    super();
    this.state = {
      meditations: [],
      favourites: []
    }
  }

  render() {
    return (
      <BaseContainer title={'Mindfull @Work'}>
        <StatusBar backgroundColor="white" barStyle="dark-content" />
        <ListMeditate navigation={this.props.navigation} cat={['DesktopYoga', 'Mindpause', 'Micro Moments', 'Mindful Meetings', 'Mindful Moments']} >
        </ListMeditate>
      </BaseContainer>
    );
  }
}