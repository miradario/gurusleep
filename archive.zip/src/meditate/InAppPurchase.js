import * as React from "react";
import { BaseContainer,BackArrow } from "../components";
import { StatusBar, StyleSheet , Text, View, Platform} from "react-native";
import COLORS from "../assets/Colors";
import ButtonGD from "../components/ButtonGD";
//import variable from './../variables/platform';



// import { ActivityIndicator } from "react-native-paper";
import * as InAppPurchases from 'expo-in-app-purchases';

export default class InAppPurchase extends React.Component<ScreenProps<>> {
 


  constructor() {
    super();
    this.state = {
      meditations: [],
      favourites: []
    }
  }
 handleBack() {
        this.props.navigation.goBack();
    }

async buyProduct() {
    
    const items = Platform.select({
      ios: [
        'dev.products.premium',
        
      ],
      android: [ 'premium'],
    });

    // Retrieve product details
    const { responseCode, results } = await InAppPurchases.getProductsAsync(items);
       
      if (responseCode === IAPResponseCode.OK) {
    results.forEach(purchase => {
      if (!purchase.acknowledged) {
        console.log(`Successfully purchased ${purchase.productId}`);
        // Process transaction here and unlock content...

        // Then when you're done
        finishTransactionAsync(purchase, true);
      }
    });
  }
/*   // Else find out what went wrong
  if (responseCode === IAPResponseCode.USER_CANCELED) {
    console.log('User canceled the transaction');
  } else if (responseCode === IAPResponseCode.DEFERRED) {
    console.log('User does not have permissions to buy but requested parental approval (iOS only)');
  } else {
    console.warn(`Something went wrong with the purchase. Received errorCode ${errorCode}`);
  }
}); */

await disconnectAsync(); 


}


  render() {
    return (
      <BaseContainer  title={'InAppPurchase'}>
        <StatusBar backgroundColor="white" barStyle="dark-content" />
          <BackArrow handleBackPress={() => this.handleBack()} />
          <Text style={style.audioTitle}>{'Access Premium Content'}</Text>
           <View style={{ marginTop: 20, textAlign: 'center', alignSelf: 'center', width: 210 }}>
              <Text style={{  color: COLORS.white, fontWeight: '900', fontSize: 17, textAlign: 'center' }}>Access incredible content</Text>
              <Text style={{  color: COLORS.white, fontWeight: '900', fontSize: 17, textAlign: 'center' }}>You are going to be premium</Text>
              <Text style={{  color: COLORS.white, fontWeight: '600', fontSize: 16, textAlign: 'center', marginTop: 10 }}>30 new meditations</Text>
            <Text style={{  color: COLORS.white, fontWeight: '600', fontSize: 16, textAlign: 'center', marginTop: 10 }}>20 special Sleep audios  </Text>
            <ButtonGD title={'Monthly'} onpress={() =>
                            this.buyProduct( )} />
          

            </View>
      </BaseContainer>
    );
  }
}

const style = StyleSheet.create({
 audioTitle: {
    marginTop: 45,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    color: COLORS.white
  }
  });