import * as React from "react";
import { BaseContainer } from "../components";
import { StatusBar } from "react-native";
import ListMeditate from "../components/ListMeditate";


export default class Meditate extends React.Component<ScreenProps<>> {

  constructor() {
    super();
    this.state = {
      meditations: [],
      favourites: []
    }
  }

  render() {
    return (
      <BaseContainer {...{ navigation }} title={'Meditate'}>
        <StatusBar backgroundColor="white" barStyle="dark-content" />
        <ListMeditate navigation={this.props.navigation} cat={['Mindfulness exercises', 'Sleep', 'Music', 'Mindful Walk']} />
      </BaseContainer>
    );
  }
}