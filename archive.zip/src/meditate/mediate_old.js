// @flow
import moment from "moment";
import * as React from "react";
import { StyleSheet, View, Text, FlatList, TouchableOpacity, Image, StatusBar } from "react-native";
import { H3 } from "native-base";
import { Ionicons } from '@expo/vector-icons';
import { BaseContainer, Task, TaskOverview, Styles } from "../components";
import type { ScreenProps } from "../components/Types";
import { getContent, getFavouritesID, removeFav, addFav} from "../../modules/firebaseAPI";
import variables from "../../native-base-theme/variables/commonColor";
import { Video } from 'expo';
import WindowDimensions from "../components/WindowDimensions";
import COLORS from "../assets/Colors";
import { LinearGradient } from 'expo-linear-gradient';
import ButtonGD from "../components/ButtonGD";



const urlimg = 'https://gesundes-und-achtsames-fuehren.de/assets/img/';
export default class Meditate extends React.Component<ScreenProps<>> {

  constructor() {
    super();
    this.state = {
      meditations: [],
      favourites: []
    }
  }


  componentDidMount() {

    // const dataSetMP = this.setContentData('Mindpause');
    const dataSetMP = this.setContentData('DesktopYoga');
    this.getFavs();
  }

  async setContentData(category) {
    if (category == 'DesktopYoga') { this.setState({ icon: 'md-body', title: 'Desktop Yoga' }); }

    if (category == 'Sleep') { this.setState({ icon: 'md-bed', title: 'Sleep' }); }

    if (category == 'Mindpause') { this.setState({ icon: 'md-bulb', title: 'Meditations' }); }

    let dataSetMP = await getContent(category);
    { this.state.category }
    this.setState({ contentMindPause: dataSetMP, category: category, contentReady: true });

    return dataSetMP;
  }

  async getFavs() {
    let favourites = await getFavouritesID()
    this.setState({ favourites: favourites })
  }

  handleHeartClick = async (currentState, key, type) => {
    if (currentState) {
      let favs = [...this.state.favourites];
      favs.splice(favs.indexOf(key), 1);
      this.setState({ favourites: favs })
      await removeFav(key)
    } else {
      let favs = [...this.state.favourites];
      favs.push(key);
      this.setState({ favourites: favs })
      await addFav(key, type, this.state.category)
    }
  }

  /* class MeditationTitle extends React.PureComponent {
  
    render() {
      const { OnPressItem } = this.props;
      return (
        <View style={styles.meditationThumb}>
          <TouchableOpacity activeOpacity={0.5} onPress=
            {() => { this.props.navigation.navigate("Audios", { category: 'Meditation', Description: this.props.Description, duration: this.props.duration, key: this.props.key, url: this.props.url, title: this.props.title, photo: urlimg + this.props.image }) }}>
            <View style={styles.thumbTitle}>
              <Text style={styles.thumbTitleText}>{this.props.title}</Text>
            </View>
          </TouchableOpacity>
        </View>
      );
    }
  }
   */


  render(): React.Node {
    const today = moment();
    const date = today.format("MMMM D");
    const dayOfWeek = today.format("dddd").toUpperCase();
    const { navigation } = this.props;


    return (
      <BaseContainer title={'Meditate'} {...{ navigation }} scrollable>
        <StatusBar backgroundColor="white" barStyle="dark-content" />
        <View style={Styles.container}>
          <View style={styles.meditationsArea}>
            <FlatList
              data={['Mindpause', 'DesktopYoga']}
              horizontal
              renderItem=
              {({ item }) =>
                <TouchableOpacity activeOpacity={0.5} onPress={() => { this.setContentData(item) }}>
                  <View style={styles.categoryTitle}>
                    <Text style={styles.thumbcategoryText}>{item}</Text>
                  </View>
                </TouchableOpacity>
              }
              keyExtractor={(item, index) => index.toString()}
            />
            <MeditationRow meditations={this.state.contentMindPause} favs={this.state.favourites} title={this.state.title} icon={this.state.icon} navigation={this.props.navigation} handleHeartClick={this.handleHeartClick} />
          </View>
        </View>
      </BaseContainer>
    );
  }
}


class MeditationThumb extends React.PureComponent {

  onFavClick = () => {
    this.props.handleHeartClick(this.props.isfav, this.props.id, this.props.type)
  }

  render() {
    const {isfav } = this.props;
    let heartColor = COLORS.white
    if (isfav) { heartColor = COLORS.orange }
    return (
      <View style={styles.meditationThumb}>
        <TouchableOpacity activeOpacity={0.5} onPress=
          {() => { this.props.navigation.navigate("Audios", { category: 'Meditation', Description: this.props.Description, duration: this.props.duration, key: this.props.key, url: this.props.url, title: this.props.title, photo: urlimg + this.props.image }) }}>
          <Image
            style={[styles.meditationThumbImage]}
            resizeMode="cover"
            source={{ uri: urlimg + this.props.image }}
          ></Image>
          <TouchableOpacity style={styles.btnFavWrapper} onPress={this.onFavClick}>
            <Ionicons name={'ios-heart'} color={heartColor} size={20} />
          </TouchableOpacity>
          <View style={styles.thumbTitle}>
            <Text style={styles.thumbTitleText}>{this.props.title}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  }
}

class MeditationRow extends React.PureComponent {

  renderItem = (data) => <MeditationThumb Description={data.Description} duration={data.duration} url={data.url} navigation={this.props.navigation} id={data.id} title={data.title} image={data.thumbnail} active={data.toggle} isfav={this.props.favs.includes(data.id)} handleHeartClick={this.props.handleHeartClick} type={data.type}/>

  render() {
    const { meditations, title, icon, favs } = this.props
    return (
      <View style={styles.meditationRowWrapper}>
        <View style={styles.meditationRow}>
          <Ionicons name={icon} style={{ color: COLORS.white }} size={30} />
          <Text style={styles.meditationRowTitle}>{title}</Text>
        </View>
        <FlatList
          //refresh={this.state.favsUpdated}
          horizontal={false}
          numColumns={2}
          showsHorizontalScrollIndicator={false}
          keyExtractor={item => item.id.toString()}
          data={meditations}
          renderItem={({ item }) => this.renderItem(item)}
          extraData = {this.props.favs} />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  videoContainer: {
    flex: 0.81,
    backgroundColor: 'transparent'
  },
  loginContainer: {
    alignItems: 'center',
    flexGrow: 0.95,
    justifyContent: 'center',
  },
  backgroundVideo: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0
  },
  header: {
    width: WindowDimensions.width,
    resizeMode: 'contain',
    flex: 1,
    position: "absolute",
    top: 0,
    zIndex: 1000
  },
  dashboard: {
    flex: 0.25,
    backgroundColor: 'red',
    borderRadius: 30,
    marginTop: -25
  },
  loadingCover: {
    width: WindowDimensions.width,
    height: WindowDimensions.height,
    position: 'absolute',
    top: 0,
    left: 0,
    zIndex: 10000000,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingGradient: {
    paddingTop: WindowDimensions.height / 3,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    alignSelf: 'stretch'
  },
  loadingText: {
    color: COLORS.white,
    fontSize: 15
  },
  meditationsArea: {
    marginTop: 10,
    flex: 1,

    alignItems: 'center',
    alignSelf: 'stretch',
    paddingLeft: 3, paddingRight: 3
  },
  meditationThumb: {

    marginTop: 15,
    paddingLeft: 7, paddingRight: 7

  },
  meditationThumbImage: {
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: 160,
    height: 140,
    opacity: 0.9,
    borderRadius: 15,
    marginBottom: -10
  },
  thumbTitle: {
    height: 25,
    padding: 5,
    backgroundColor: COLORS.blue,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15
  },
  thumbTitleText: {
    fontSize: 12,

    textAlign: "center",
    color: COLORS.white
  },
  categoryTitle: {
    height: 25,
    padding: 15,
    marginRight: 15,
    backgroundColor: COLORS.blue,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',

  },

  thumbcategoryText: {
    fontSize: 16,

    textAlign: "center",
    color: COLORS.white
  },
  meditationRow: {
    flexDirection: "row",
    alignItems: "center",
    width: '50%',
    marginBottom: 15,
    marginTop: 15
  },
  meditationRowWrapper: {
    flex: 1,
    marginBottom: 40,

    alignContent: "space-between",
    alignItems: "center",
    paddingBottom: 25

  },
  meditationRowTitle: {
    color: COLORS.white,
    fontSize: 16,
    marginLeft: 10,
    marginTop: 15,
    fontWeight: 'bold'
  },
  btnFavWrapper: {
    position: 'absolute',
    top: 7,
    right: 7
  }
});
