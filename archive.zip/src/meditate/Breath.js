import * as React from "react";
import {  BaseContainer} from "../components";
import { StatusBar} from "react-native";
import ListMeditate from "../components/ListMeditate";


export default class Breath extends React.Component<ScreenProps<>> {

  constructor() {
    super();
    this.state = {
      meditations: [],
      favourites: []
    }
  }

render() {
    

    return (
      <BaseContainer title={'Breath'} scrollable>
      
        <StatusBar backgroundColor="white" barStyle="dark-content" />
        <ListMeditate navigation={this.props.navigation} cat={[ 'Breathing exercises', 'Breathing exercise Course']} >
        </ListMeditate>
      
    
      </BaseContainer>
    );

 }
 
}
