import React, { Component } from 'react';
import { StyleSheet, View, ScrollView, Text, Image, PanResponder, Dimensions, Animated, StatusBar } from 'react-native';
import loremipsum from 'lorem-ipsum-react-native';
import { BaseContainer } from "../components";
import randomUser from '../randomUser';
import randomColor from '../randomColor';
import AnchorRadial from '../components/AnchorRadial';
import AnchorRadialChild from '../components/AnchorRadialChild';
import AnimatedLinearGradient from '../components/AnimatedLinearGradient';
import PanResponderTouchable from '../components/PanResponderTouchable';
import COLORS from "../assets/Colors";

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const { height: SCREEN_HEIGHT } = Dimensions.get('window');



const ima1 = { uri: 'https://www.gesundes-und-achtsames-fuehren.de/assets/img/christoph.png'};
const ima2 = { uri: 'https://www.gesundes-und-achtsames-fuehren.de/assets/img/maria.png'};
const ima3 = { uri: 'https://www.gesundes-und-achtsames-fuehren.de/assets/img/nia.png'};


export default class Teachers extends Component {
      
    state = {
        primaryColor: COLORS.orange,
        secondaryColor: COLORS.blue,
        selected: 1,
        playing: null,
        users: [
    {
        name: 'Christopher',
        source:  ima1 ,
        header: 'Christopher Glaser',
        text: 'Christoph Glaser, 1972 geboren in Basel, ist Geschäftsführer des TLEX Institutes und internationaler Berater, Trainer und Coach im Bereich Mindfulness, Führung und Change. In den letzten 20 Jahren unterrichtete er in Organisationen wie Accenture, General Electric, der Weltbank-Programms und der Harvard Business School sowie vielen mittelständischen Firmen wie Supercell oder SinnerSchrader. Christoph Glaser studierte Psychologie in Basel und schloss einen Master in Public Policy an der Humboldt Viadrina School for Governance in Berlin ab. Er ist zertifizierter Führungskräftetrainer des Weltbank-Programms „Greater than Leadership”, sowie durch Integral Coaching Canada zertifizierter Integral Associate Coach',
        primaryColor: COLORS.orange,
        secondaryColor: COLORS.blue
    },
    {
        name: 'Maria',
        source:  ima2,
        header: 'Maria Lorenz',
        text: 'Maria Lorenz, 1983 geboren in Hamburg, leitet das deutsche TLEX Team und arbeitet seit über 10 Jahren als Beraterin und Trainerin im Bereich Personal- und Organisationsentwicklung. Ihre Schwerpunkte liegen im Bereich Mindfulness, Führung und Teamentwicklung. Europaweit betreut sie Kunden wie Microsoft, BMW, General Electric und die Weltbank sowie mittelständische Firmen wie SinnerSchrader oder Supercell. Ihr Betriebswirtschaftsdiplom mit Schwerpunkt Marketing und Wirtschaftspsychologie erhielt sie an der Hamburger Universität. Maria Lorenz ist zertifizierter systemischer Coach.',
        primaryColor:  COLORS.blue,
        secondaryColor: COLORS.orange
    },
    {
        name: 'Nia',
        source:  ima3,
        header: 'Dr. Nia Julia Choi',
        text: 'Nia, 1982 geboren in Berlin, hat Schulungen und Beratungsprojekte für TLEX mit Unternehmen wie Accenture, General Electric, BearingPoint und Roche Pharmaceuticals durchgeführt. Ihre Fachgebiete sind Mindfulness, Führung und Unternehmenskultur. Vor ihrem Eintritt bei TLEX war Nia als Wissenschaftlerin im Bereich Betriebswirtschaft und Social Entrepreneurship tätig. Sie hat ein Diplom in Betriebswirtschaftslehre mit dem Schwerpunkt Führung von der Freien Universität Berlin und hat am Tata Institute of Social Sciences promoviert.',
        primaryColor: COLORS.orange,
        secondaryColor:  COLORS.blue
    }
    ]
    }
    xOffset = new Animated.Value(0)
    onPanResponderMove = Animated.event(
        [null, { dx: this.xOffset }]
    )
    onPanResponderRelease = (...args) => {
        this.setState({ disableUsers: false });
        this.radial.onPanResponderRelease(...args);
    }
    panResponder = PanResponder.create({
        onMoveShouldSetPanResponderCapture: () => true,
        onPanResponderMove: this.onPanResponderMove,
        onPanResponderRelease: this.onPanResponderRelease
    })
    render() {
        const { navigation } = this.props;
        return (
             <BaseContainer title={'Teachers'} {...{ navigation }} scrollable >
            <StatusBar backgroundColor="white" barStyle="dark-content" />
                <AnimatedLinearGradient colors={[
                    this.state.primaryColor,
                    this.state.secondaryColor
                ]} />
                <Animated.View
                    style={[styles.pages, { transform: [{ translateX: this.xOffset }] }]}
                    {...this.panResponder.panHandlers}>
                    {this.state.users.map(({ header, text }, i) => (
                        <View key={i} style={styles.hero}>
                        
                            <Text style={styles.header}>{header}</Text>
                            <ScrollView style={styles.scroll} scrollEnabled >
                            <Text style={styles.text}>{text}</Text>
                            </ScrollView>
                        </View>
                    ))}
                </Animated.View>
                <View style={styles.circle} />
                <AnchorRadial
                    ref={c => (this.radial = c)}
                    style={styles.radial}
                    xOffset={this.xOffset}
                    onValueChanged={(i) => {
                        const { primaryColor, secondaryColor } = this.state.users[i];
                        this.setState({
                            primaryColor,
                            secondaryColor,
                            selected: i
                        });
                    }}
                    value={this.state.selected}>
                    {this.state.users.map(({ source }, i) => (
                        <AnchorRadialChild key={i} playing={this.state.playing === i}>
                            <PanResponderTouchable
                                onPressOut={() => {
                                    if (this.state.selected === i)
                                        {
                                            this.setState({playing: i});
                                        }
                                    this.setState({selected: i});
                                }}>
                                <Image style={styles.image} source={source} />
                            </PanResponderTouchable>
                        </AnchorRadialChild>
                    ))}
                </AnchorRadial>
       
            </BaseContainer >
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'gray',
        flex: 1
    },
    pages: {
         flexDirection: 'row',
         height: 50

    },
    hero: {
        paddingTop: 20,
        paddingHorizontal: 20,
        width: SCREEN_WIDTH,
        height: 400
    },
    scroll: {
        height: 60,
        
    },
    header: {
        fontSize: 35,
        fontWeight: 'bold',
        color: 'white',
        backgroundColor: 'transparent',
        marginBottom: 10
    },
    text: {
        fontSize: 20,
        color: 'rgba(255, 255, 255, 0.5)',
        backgroundColor: 'transparent',
        marginBottom: 100
    },
    circle: {
        position: 'absolute',
        alignSelf: 'center',
        width: 600,
        height: 600,
        borderRadius: 300,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        bottom: -400
    },
    radial: {
        position: 'absolute',
        bottom: -400,
        alignSelf: 'center'
    },
    image: {
        width: 80,
        height: 80
    }
});
