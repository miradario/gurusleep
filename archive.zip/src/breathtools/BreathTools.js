// @flow
import * as React from "react";
import {StyleSheet, Image, Dimensions, View} from "react-native";
import {H1} from "native-base";

import {BaseContainer, Images, Small} from "../components";
import type {ScreenProps} from "../components/Types";

import variables from "../../native-base-theme/variables/commonColor";

export default class BreathTools extends React.PureComponent<ScreenProps<>> {

    render(): React.Node {
        return (
            <BaseContainer title="Breathing Tool" navigation={this.props.navigation} scrollable>
                <Group title="Pranayamas" description="3 ITEMS" picture={Images.music} />
                <Group title="Sudarshan Kriya" description="" picture={Images.architecture} />
                <Group title="Meditation Sahaj" description="" picture={Images.travel} />
                <Group title="Padma Sadhana" description="" picture={Images.architecture} />
                <Group title="Sun Saludation" description="" picture={Images.travel} />
            </BaseContainer>
        );
    }
}

type GroupProps = {
    title: string,
    description: string,
    picture: string
};

class Group extends React.PureComponent<GroupProps> {

    render(): React.Node {
        const {title, description, picture} = this.props;
        return (
            <View style={style.container}>
                <Image source={picture} resizeMode="cover" style={style.img} />
                <H1>{title}</H1>
                <Small style={style.text}>{description.toUpperCase()}</Small>
            </View>
        );
    }
}

const {width} = Dimensions.get("window");
const style = StyleSheet.create({
    container: {
        width,
        height: width * (402 / 750),
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
    },
    img: {
        ...StyleSheet.absoluteFillObject,
        width,
        height: width * (402 / 750)
    },
    text: {
        borderColor: "white",
        borderWidth: variables.borderWidth,
        padding: variables.contentPadding,
        margin: variables.contentPadding
    }
});
