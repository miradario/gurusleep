const COLORS = {
    orange: '#f8a571',
    blue: '#009bbd',
    white: '#ffffff',
    gray: '#6d6f71',
    lightblue: '#a3e1ec',
    black: '#6d6f71',
    ultralightblue: '#a2dfec',
    lightgray: '#d3d3d3'
  }
  
  export default COLORS;