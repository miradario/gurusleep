import React, { Component } from 'react';
import {
    Animated,
    Dimensions,
    ScrollView,
    StyleSheet,
    TouchableWithoutFeedback,
    View,
    Image,
    TouchableOpacity
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Images from "../images";
import { Text } from "native-base";
import * as Easing from "react-native/Libraries/Animated/src/Easing";
import { LinearGradient } from 'expo-linear-gradient';
import COLORS from "../../assets/Colors"
import ChallegeIndicator from "../ChallengeIndicator"
import { getChallenges } from "../../../modules/firebaseAPI"
import firebase from "firebase";
import * as challengesAPI from "../../../modules/challengesAPI.js";
import ButtonGD from "../ButtonGD";
import AnimationTypingText from '../AnimationTypingText';
import translate from '../../../utils/language';
import { State, PanGestureHandler } from 'react-native-gesture-handler'


const { width, height } = Dimensions.get('window');

export default class BottomUpPanel extends Component {

    static defaultProps = {
        isOpen: false
    };

    // Define state
    state = {
        open: false,
        spinValue: new Animated.Value(0),
        //  challenges: [],
        listingData: []
    };

    config = {
        position: {
            max: height,
            start: height - this.props.startHeight,
            end: this.props.topEnd,
            min: this.props.topEnd,
            animates: [
                () => this._animatedHeight
            ]
        },
        width: {
            end: width,
            start: width
        },
        height: {
            end: height,
            start: this.props.startHeight
        }

    };

    _animatedHeight = new Animated.Value(this.props.isOpen ? this.config.height.end : this.config.height.start);

    _animatedPosition = new Animated.Value(this.props.isOpen
        ? this.config.position.end
        : this.config.position.start);

    componentWillMount() {
        this.readData();
        this._animatedPosition.addListener((value) => {
            //Every time that position changes then actualize the related properties. I.e: height, so the view
            //has the interpolated height
            this.config.position.animates.map(item => {
                item().setValue(value.value);
            })
        });
        // Reset value once listener is registered to update depending animations
        this._animatedPosition.setValue(this._animatedPosition._value);
    }

    // Handle isOpen prop changes to either open or close the window
    componentWillReceiveProps(nextProps) {
        // isOpen prop changed to true from false
        if (!this.props.isOpen && nextProps.isOpen) {
            this.open();
        }
        // isOpen prop changed to false from true
        else if (this.props.isOpen && !nextProps.isOpen) {
            this.close();
        }
    }

    onMountain(key, title) {
        this.props.onMountain(key, title)
    }

    onNewChallenge() {
        this.props.onNewChallenge()
    }

    async readData() {
        /*   let challenges = [];
          getChallenges().then((result) => {
            result.forEach(function (data) {
              let challenges = data.val();
              console.log(challenges);
              challenges.key = data.key;
              challenges.push(challenges);
            })
            this.setState({
              loading: false,
              challenges: challenges
            })
          }).catch(error => {
            this.setState({ loading: false })
          })
          console.log("read data") */

        this.database = firebase.database();
        const userId = firebase.auth().currentUser.uid;
        let q = this.database.ref("/Users/" + userId + "/Challenge");
        var current = [];
        q.once("value", snapshot => {
            snapshot.forEach(function (data) {
                let result = data.val();
                let currentday = challengesAPI.current_day(result.daystart);
                let finished = challengesAPI.finished(currentday);
                if(result.active == 'current' && !finished){
                    result["key"] = data.key;
                    current.push(result);
                }
            });
        }).then(() => {
            this.setState({
                listingData: current,
                qch: 0,
            });
        });

    }

    handleGesture = (evt) => {
        let { nativeEvent } = evt
        if (nativeEvent.state === State.ACTIVE) {
            this.toggle()
        }
    }

    render() {
        const { content } = this.props;

        //const userEmail = firebase.auth().currentUser.displayName.length>1? firebase.auth().currentUser.displayName : firebase.auth().currentUser.email  ;
        const userEmail = firebase.auth().currentUser.email;


        // Height according to position
        let animatedHeight = this._animatedHeight.interpolate({
            inputRange: [this.config.position.end, this.config.position.start],
            outputRange: [this.config.height.end, this.config.height.start],
        });
        this.state.qch = 0;

        // Icon rotation
        const spin = this.state.spinValue.interpolate({
            inputRange: [0, 1],
            outputRange: ['0deg', '180deg']
        });

        const createChallengeShortcut = <CreateChallengeShortcut onNewChallenge={this.props.onNewChallenge} />
        return (
            <PanGestureHandler onHandlerStateChange={this.handleGesture} activeOffsetY={[-80, 80]}>
                <Animated.View style={[styles.buttonUpPanelView, { height: animatedHeight }]}>
                    <Animated.View
                        style={[styles.content, {
                            // Add padding at the bottom to fit all content on the screen
                            paddingBottom: this.props.topEnd,
                            width: width,
                            backgroundColor: this.state.open ? COLORS.blue : 'transparent',
                            // Animate position on the screen
                            transform: [{ translateY: this._animatedPosition }, { translateX: 0 }]
                        }]}
                    >
                        <TouchableWithoutFeedback>
                            <Animated.View style={{ height: this.props.startHeight }}>
                                <View style={[this.props.bottomUpSlideBtn, { width: width - 30, height: this.props.startHeight }]}>
                                    <LinearGradient
                                        colors={[COLORS.blue, this.state.open ? COLORS.blue : COLORS.ultralightblue]}
                                        style={{ flex: 1, alignItems: 'center', borderRadius: this.state.open ? 0 : 30, padding: 15 }}
                                        start={[1, 0]}
                                        end={[1, 1]}>
                                        <View style={[styles.dashboardView, { marginTop: this.props.dashMargin }]}>
                                            <Image style={{ height: 30, width: 30 }} source={Images.smile}></Image>
                                            {/* <Ionicons name={"md-happy"} style={{ color: COLORS.white }} size={30} /> */}
                                            <View style={{ paddingLeft: 10 }}>
                                                <AnimationTypingText triggerAnimation={this.props.triggerAnimation} style={styles.userGreeting} text={translate("hi") + ", " + userEmail} color={COLORS.white} fontSize={15}>{translate("hi")}, {userEmail}</AnimationTypingText>
                                                <Text style={styles.userGreeting}>{translate("last_challenge")}</Text>
                                            </View>
                                        </View>
                                        {(this.state.listingData.length) ?
                                            this.state.listingData.map(x => {

                                                let currentday = challengesAPI.current_day(x.daystart);
                                                let finished = challengesAPI.finished(currentday);
                                                let completed = challengesAPI.completed_days(x);

                                                notstarted = (currentday == -1) ? notstarted = true : notstarted = false;
                                                 if (x.active =='current'){
                                                        if (!notstarted && !finished) {
                                                            this.state.qch++;
                                                            if (this.state.qch == 1) {
                                                                let completed = challengesAPI.completed_days(x);

                                                                return <ChallegeIndicator
                                                                    triggerAnimation={this.props.triggerAnimation} 
                                                                    key={this.state.qch}
                                                                    daysCompleted={currentday} title={x.title} image={x.image}
                                                                    onmountain={() => this.onMountain(x.key, x.title)}
                                                                />
                                                            }
                                                        }
                                                 }
                                            })
                                            : createChallengeShortcut
                                        }
                                    </LinearGradient>
                                </View>
                            </Animated.View>
                        </TouchableWithoutFeedback>

                        {/* Scrollable content */}
                        <ScrollView
                            ref={(scrollView) => { this._scrollView = scrollView; }}
                            // Enable scrolling only when the window is open
                            scrollEnabled={this.state.open}
                            // Hide all scrolling indicators
                            showsHorizontalScrollIndicator={false}
                            showsVerticalScrollIndicator={false}
                            // Trigger onScroll often
                            scrollEventThrottle={16}
                            onScroll={this._handleScroll}
                        >
                            {/* Render content components */}
                            {content()}
                        </ScrollView>
                    </Animated.View>
                </Animated.View>
            </PanGestureHandler>

        );
    }


    open = () => {
        this.props.panelOpened()
        this.setState({ open: true }, () => {
            Animated.timing(this._animatedPosition, {
                toValue: this.config.position.end,
                duration: 600,
            }).start();
            Animated.timing(
                this.state.spinValue,
                {
                    toValue: 1,
                    duration: 600,
                    easing: Easing.linear,
                    useNativeDriver: true
                }
            ).start()
        });

    };

    close = () => {
        this.props.panelClosed()
        this._scrollView.scrollTo({ y: 0 });
        Animated.timing(this._animatedPosition, {
            toValue: this.config.position.start,
            duration: 600,
        }).start(() => {
            this.setState({ open: false })
        });
        Animated.timing(
            this.state.spinValue,
            {
                toValue: 0,
                duration: 600,
                easing: Easing.linear,
                useNativeDriver: true
            }
        ).start();
    };

    toggle = () => {
        if (!this.state.open) {
            this.open();
        }
        else {
            this.close();
        }
    };

}

class CreateChallengeShortcut extends React.PureComponent {

    state = {
        itemVisible: true
    }
    onBtnClick = () => {
        this.props.onNewChallenge()
    }
    render() {
        return (
            <ButtonGD title={translate("CreateChallenge")} onpress={() => this.onBtnClick()} />
        );
    }
}

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        justifyContent: 'flex-end',
        backgroundColor: 'transparent'
    },
    content: {
        height: height,
    },
    buttonUpPanelView: {
        position: 'absolute', bottom: 0, width: width, alignItems: 'center', justifyContent: 'flex-end',
        backgroundColor: 'transparent'
    },
    dashboardView: {
        flexDirection: "row",
        alignItems: "center",
        width: 300
    },
    userGreeting: {
        fontSize: 15,
        color: "white",
        fontWeight: "bold"
    }
});
