import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity } from "react-native";
import COLORS from "../assets/Colors";
import { FontAwesome as Icon } from "@expo/vector-icons";

export default class BackArrow extends Component {

    handlePress(){
        this.props.handleBackPress()
    }

    render() {

        return (
            <View style={styles.mainWrapper}>
                <TouchableOpacity onPress={() => this.handlePress()}>
                    <View style={styles.circle}>
                        <Icon name={'chevron-left'} size={17} color={COLORS.orange}></Icon>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    mainWrapper: {
        position: 'absolute',
        top: 10,
        left: 10,
        zIndex: 10000
    },
    circle: {
        width: 35,
        height: 35,
        borderRadius: 50,
        backgroundColor: COLORS.white,
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 10000,
        marginTop: 5,
        marginLeft: 5,
        paddingRight: 2
    },
    text: {
        textAlign: 'center',
        paddingRight: 15
    }
});
