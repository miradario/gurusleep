// @flow
import * as React from "react";
import { StyleSheet, Image, StatusBar, View} from "react-native";
import { Button, Header as NBHeader, Left, Body, Title, Right, Icon, Content } from "native-base";
import { Ionicons } from "@expo/vector-icons";
import Constants from "expo-constants";
import { LinearGradient } from 'expo-linear-gradient';
import Avatar from "./Avatar";
import Images from "./images";
import WindowDimensions from "./WindowDimensions";
import Container from "./Container";
import Footer from "./Footer";
import type { NavigationProps, ChildrenProps } from "./Types";
import COLORS from "../assets/Colors";

const { height, width } = WindowDimensions

// import variables from "../../native-base-theme/variables/commonColor";
type BaseContainerProps = NavigationProps<> & ChildrenProps & {
    title: string | React.Node
};

export default class BaseContainer extends React.PureComponent<BaseContainerProps> {
    render(): React.Node {
        const { title, navigation, endGradient, startGradient, backBtn, scrollable, noPadding} = this.props;
        const showBackButton = (backBtn ? true : false)

        const scrollableContent = <Content contentContainerStyle={{ flexGrow: 1, paddingLeft: noPadding ? 0 : 10, paddingRight: noPadding ? 0 : 10 }}> 
                                    {this.props.children} 
                                  </Content>
        const noScrollableContent = <View style={{ flex: 1, paddingLeft: noPadding ? 0 : 10, paddingRight: noPadding ? 0 : 10 }}>{this.props.children}</View>

        return (
            <Container safe>
                <LinearGradient
                    colors={[(startGradient ? startGradient : COLORS.blue), (endGradient ? endGradient : COLORS.lightblue)]}
                    style={style.gradientBg}
                    start={[1, 0]}
                    end={[1, 1]}>
                        {scrollable ? scrollableContent : noScrollableContent}
                </LinearGradient>
                {/* <NBHeader noShadow style={style.header}>
                    <Left>
                        {showBackButton && (
                            <Button onPress={() => navigation.goBack(null)} transparent>
                                <Ionicons name="ios-arrow-back" size={32} color={COLORS.gray} />
                            </Button>
                        )}
                    </Left>
                    <Body>
                        {
                            typeof (title) === "string" ? <Title style={style.title}>{title.toUpperCase()}</Title> : title
                        }
                    </Body>
                    <Right style={style.right}>
                        <Button onPress={() => navigation.navigate("Profile")} transparent>

                        </Button>
                    </Right>
                </NBHeader> */}
            </Container>
        );
    }
}

const style = StyleSheet.create({
    img: {
        width: WindowDimensions.width,
        height: WindowDimensions.height, //lo oculto para el que funcione con el s10 - Constants.statusBarHeight,
        top: Constants.statusBarHeight
    },
    gradientBg: {
        flex: 1,
        alignItems: 'stretch',
        borderRadius: 40,
        margin: 15,
        marginBottom: 55,
    },
    right: {
        alignItems: "center"
    },
    icon: {
        fontSize: 32
    },
    largeIcon: {
        fontSize: 64,
        height: 64
    },
    imgHeader: {
        width: width,
        height: width / 750 * 150,
        position: "absolute",
        top: 0,
        resizeMode: 'contain'
    },
    header: {
        backgroundColor: COLORS.white
    },
    title: {
        color: COLORS.gray
    }
});
