import React, { Component } from "react";
import { StyleSheet, View,  TouchableOpacity, Text } from "react-native";
import COLORS from "../assets/Colors";

export default class ButtonGD extends Component {

 render() {
        const {title, onpress } = this.props;


  return (
          <View style={style.loginContainer}>
                <TouchableOpacity style={style.loginButton} onPress={onpress}
                >
                            <Text style={style.loginText}>{title}</Text>
                        </TouchableOpacity>
                    </View>
  )

 }
}

const style = StyleSheet.create({
 loginButton: {
        marginTop: 20,
        paddingTop: 15,
        paddingBottom: 15,
        backgroundColor: COLORS.orange,
        borderRadius: 25,
        width: 200,
        alignContent: 'center'
    },
    loginText: {
        textAlign: 'center',
        color: COLORS.white,
        fontWeight: 'bold',
        fontFamily: "Avenir-Black"
    },
    loginContainer: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center'
    }
    });