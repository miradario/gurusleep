import moment from "moment";
import React, { Component } from "react";
import { StyleSheet, View, Text, FlatList, TouchableOpacity, Image, StatusBar, ActivityIndicator, Alert } from "react-native";
import { H3 } from "native-base";
import { Ionicons } from '@expo/vector-icons';
import type { ScreenProps } from "../components/Types";
import { FavButton, LockButton } from "../components";
import { getContent, getFavouritesID, removeFav, addFav } from "../../modules/firebaseAPI";
import variables from "../../native-base-theme/variables/commonColor";
import { Video } from 'expo';
import WindowDimensions from "./WindowDimensions";
import COLORS from "../assets/Colors";
import { LinearGradient } from 'expo-linear-gradient';
import i18n from "i18n-js";
// import { ActivityIndicator } from "react-native-paper";


const urlimg = 'https://gesundes-und-achtsames-fuehren.de/assets/img/';
export default class ListMeditate extends Component {

  constructor() {
    super();
    this.state = {
      meditations: [],
      favourites: [],
      selectedCat: 0
    }
  }

  componentDidMount() {
    this.setContentData(this.props.cat[0]);
    this.getFavs();
    this.focusListener = this.props.navigation.addListener(
      "didFocus",
      () => {
        if (i18n.changelocale) {
          this.setContentData(this.props.cat[0]);
          this.getFavs();
        }
      }
    )
  }

  async setContentData(category) {
    if (category == 'DesktopYoga') { this.setState({ icon: 'md-body', title: 'Desktop Yoga' }); }
    if (category == 'Sleep') { this.setState({ icon: 'md-bed', title: 'Sleep' }); }
    if (category == 'Mindpause') { this.setState({ icon: 'md-bulb', title: 'Meditations' }); }
    if (category == 'Work') { this.setState({ icon: 'md-bulb', title: 'Mindfullness @Work' }); }

    let dataSetMeditations = await getContent(category);
    this.setState({ meditations: dataSetMeditations, category: category, contentReady: true });
  }

  async getFavs() {
    let favourites = await getFavouritesID()
    this.setState({ favourites: favourites })
  }

  handleHeartClick = async (currentState, key, type) => {
    if (currentState) {
      let favs = [...this.state.favourites];
      favs.splice(favs.indexOf(key), 1);
      this.setState({ favourites: favs })
      await removeFav(key)
    } else {
      let favs = [...this.state.favourites];
      favs.push(key);
      this.setState({ favourites: favs })
      await addFav(key, type, this.state.category)
    }
  }

  handleCategoryChange = (category, id) => {
    this.setState({ contentReady: false, selectedCat: id })
    this.setContentData(category)
  }

  render(): React.Node {
    const { cat } = this.props;
    const today = moment();
    const date = today.format("MMMM D");
    const dayOfWeek = today.format("dddd").toUpperCase();
    const { navigation } = this.props;

    return (

      <View style={styles.container}>
        <View style={styles.meditationsArea}>
          <View style={styles.categoryWrapper}>
            <FlatList
              refresh={this.state.selectedCat}
              data={cat}
              horizontal
              renderItem={({ item, index }) =>
                <CategoryButton category={item} categoryChange={this.handleCategoryChange} id={index} active={(this.state.selectedCat == index)} />
              }
              keyExtractor={(item, index) => index.toString()}
              ListHeaderComponentStyle={{ justifyContent: 'space-between' }}
            />
          </View>
          {this.state.contentReady ?
            (<MeditationRow meditations={this.state.meditations} favs={this.state.favourites} title={this.state.title} icon={this.state.icon} navigation={this.props.navigation} handleHeartClick={this.handleHeartClick} />) :
            (
              <View style={styles.activityIndicatorWrapper}>
                <ActivityIndicator color="white" size="large" />
              </View>
            )
          }
        </View>
      </View>

    );
  }
}

class CategoryButton extends React.PureComponent {

  handleCategoryChange = () => {
    this.setState({ selected: true })
    this.props.categoryChange(this.props.category, this.props.id)
  }

  render() {
    return (
      <TouchableOpacity activeOpacity={0.5} onPress={() => { this.handleCategoryChange() }}>
        <View style={[styles.categoryTitle, { backgroundColor: (this.props.active ? COLORS.orange : COLORS.blue) }]}>
          <Text style={styles.thumbcategoryText}>{this.props.category}</Text>
        </View>
      </TouchableOpacity>
    )
  }
}





class MeditationThumb extends React.PureComponent {


buyProduct() {
   this.props.navigation.navigate("InAppPurchase");
   
}



  onFavClick = () => {
    this.props.handleHeartClick(this.props.isfav, this.props.id, this.props.type)
  }
   
   promptBuy = () => {
    const title = 'Buy Premium Suscription' ;
    const message = 'Do you want to access premium content?';
    const buttons = [
      { text: 'Cancel', type: 'cancel' },
      { text: 'Suscribe' ,  onPress: () => this.buyProduct()},
    ];
    Alert.alert(title, message, buttons);
  }

  onThumbClick(locked) {
    if (locked) { 
        this.buyProduct();
    }else{
      if (this.props.type == 'audio') {
        this.props.navigation.navigate("Audios", {
          category: 'Meditation',
          Description: this.props.Description,
          duration: this.props.duration,
          key: this.props.id,
          url: this.props.url,
          title: this.props.title,
          photo: urlimg + this.props.image
        })
      } else {
        this.props.navigation.navigate("Player", {
          category: 'Meditation',
          Description: this.props.Description,
          duration: this.props.duration,
          key: this.props.id,
          url: this.props.url,
          title: this.props.title,
          photo: urlimg + this.props.image
        })
      }
    }
  }

  render() {
    const { isfav, lock } = this.props;
    let locked=false;
    let heartColor = COLORS.white
    let title = this.props.title.length > 20 ? this.props.title.substring(0, 18) + "..." : this.props.title
    if (isfav) { heartColor = COLORS.orange }
    if (lock==1) { locked = true }
    return (
      <View style={styles.meditationThumb}>
        <TouchableOpacity activeOpacity={0.5} onPress={() => this.onThumbClick(locked)}>
          <Image
            style={[styles.meditationThumbImage]}
            resizeMode="cover"
            source={{ uri: urlimg + this.props.image }}
          ></Image>
          <FavButton handleFavPress={() => this.onFavClick()} heartColor={heartColor} />
          <LockButton locked={locked} />
          <View style={styles.thumbTitle}></View>
          <Text style={styles.thumbTitleText}>{title}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

class MeditationRow extends React.PureComponent {

  renderItem = (data) =>
    <MeditationThumb
      Description={data.Description}
      duration={data.duration}
      url={data.url}
      navigation={this.props.navigation}
      id={data.id}
      title={data.title}
      image={data.thumbnail}
      active={data.toggle}
      lock={data.lock}
      isfav={this.props.favs.includes(data.id)}
      handleHeartClick={this.props.handleHeartClick}
      type={data.type} />

  render() {
    const { meditations, title, icon } = this.props
    return (
      <View style={styles.meditationRowWrapper}>
        <View style={styles.meditationRow}>
          <Ionicons name={icon} style={{ color: COLORS.white }} size={30} />
          <Text style={styles.meditationRowTitle}>{title}</Text>
        </View>
        <FlatList
          style={{ alignSelf: 'stretch' }}
          columnWrapperStyle={{ justifyContent: 'space-between' }}
          horizontal={false}
          numColumns={2}
          showsHorizontalScrollIndicator={false}
          keyExtractor={item => item.id.toString()}
          data={meditations}
          renderItem={({ item }) => this.renderItem(item)}
          extraData={this.props.favs} />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  videoContainer: {
    flex: 0.81,
    backgroundColor: 'transparent'
  },
  loginContainer: {
    alignItems: 'center',
    flexGrow: 0.95,
    justifyContent: 'center',
  },
  backgroundVideo: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0
  },
  header: {
    width: WindowDimensions.width,
    resizeMode: 'contain',
    flex: 1,
    position: "absolute",
    top: 0,
    zIndex: 1000
  },
  dashboard: {
    flex: 0.25,
    backgroundColor: 'red',
    borderRadius: 30,
    marginTop: -25
  },
  loadingCover: {
    width: WindowDimensions.width,
    height: WindowDimensions.height,
    position: 'absolute',
    top: 0,
    left: 0,
    zIndex: 10000000,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingGradient: {
    paddingTop: WindowDimensions.height / 3,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    alignSelf: 'stretch'
  },
  loadingText: {
    color: COLORS.white,
    fontSize: 15
  },
  meditationsArea: {
    marginTop: 10,
    flex: 1,
    alignItems: 'center',
    alignSelf: 'stretch',
    paddingLeft: 3, paddingRight: 3
  },
  categoryWrapper: {
    height: 30,
    marginTop: 15
  },
  meditationThumb: {
    marginTop: 15,
    paddingLeft: 7, paddingRight: 7
  },
  meditationThumbImage: {
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: WindowDimensions.width*0.35,
    height: (WindowDimensions.width*0.35)*(140/130),
    opacity: 0.9,
    borderRadius: 15,
  },
  thumbTitle: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 25,
    backgroundColor: '#000000',
    opacity: 0.3,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15
  },
  thumbTitleText: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 5,
    fontSize: 12,
    textAlign: "center",
    color: COLORS.white
  },
  categoryTitle: {
    height: 30,
    padding: 15,
    paddingTop: 5,
    paddingBottom: 5,
    marginRight: 15,
    backgroundColor: COLORS.blue,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  thumbcategoryText: {
    fontSize: 16,
    textAlign: "center",
    color: COLORS.white
  },
  meditationRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    marginTop: 15
  },
  meditationRowWrapper: {
    flex: 1,
    alignContent: "space-between",
    alignItems: "center",
    paddingBottom: 25,
    alignSelf: 'stretch',
    paddingLeft: 10,
    paddingRight: 10
  },
  meditationRowTitle: {
    color: COLORS.white,
    fontSize: 16,
    marginLeft: 10,
    fontWeight: 'bold'
  },
  btnFavWrapper: {
    position: 'absolute',
    top: 7,
    right: 7
  },
  activityIndicatorWrapper: {
    flex: 1,
    alignContent: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
    height: 500
  }
});
