import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity } from "react-native";
import COLORS from "../assets/Colors";
import { Ionicons } from "@expo/vector-icons";

export default class FavButton extends Component {

    handlePress(){
        this.props.handleFavPress()
    }

    render() {
        const {heartColor} = this.props
        return (
            <TouchableOpacity style={styles.btnFavWrapper} onPress={() => this.handlePress()}>
                <View style={styles.favOutline}>
                    <Ionicons name={'md-heart'} color={heartColor} size={20} />
                </View>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    btnFavWrapper: {
        position: 'absolute',
        top: 7,
        right: 7
    },
    favOutline: {
        height: 30,
        width: 30,
        borderRadius: 50,
        backgroundColor: COLORS.lightgray,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 3
    }
});
