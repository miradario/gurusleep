// eslint-disable-next-line import/prefer-default-export
export interface Channel {
  id: string;
  title: string;
  description: string;
  type: string;
  Cover: string;
}
