// @flow
/* eslint-disable global-require */
import { Asset } from "expo-asset";

import Login from "../../../assets/images/login.png";
import SignUp from "../../../assets/images/signUp.jpg";
import Walkthrough from "../../../assets/images/walkthrough.jpg";
import Profile from "../../../assets/images/profile.jpg";
import Done from "../../../assets/images/done.png";

import DefaultAvatar from "../../../assets/images/avatars/default-avatar.jpg";
import DefaultAvatar1 from "../../../assets/images/avatars/avatar-1.jpg";
import DefaultAvatar2 from "../../../assets/images/avatars/avatar-2.jpg";
import DefaultAvatar3 from "../../../assets/images/avatars/avatar-3.jpg";

import iconBreath from "../../assets/menuIcons/menu-icon-breath.png";
import iconWork from "../../assets/menuIcons/menu-icon-compu.png";
import iconChallenge from "../../assets/menuIcons/menu-icon-mountain.png";
import iconBreak from "../../assets/menuIcons/menu-icon-stones.png";
import iconHome from "../../assets/menuIcons/menu-icon-heart.png";

import Music from "../../../assets/images/music.jpg";
import Architecture from "../../../assets/images/architecture.jpg";
import Travel from "../../../assets/images/travel.jpg";

import Logo from "../../../assets/images/logo.png";
import Header from "../../../assets/images/app_header.png";

import MT1 from "../../../assets/images/MT_1.png";
import Tools_1 from "../../../assets/images/tools_1.png";

import splash from "../../../assets/splash_tlex.png"
import smile from "../../../assets/images/smile.png"
import tlex_white from "../../../assets/images/tlex_white.png"
import arrow_right from "../../../assets/images/arrow_right.png"
import play_btn from "../../../assets/images/round_play.png"


export default class Images {
    static login = Login;
    static signUp = SignUp;
    static walkthrough = Walkthrough;
    static profile = Profile;
    static done = Done;

    static iconHome = iconHome;
    static iconBreak = iconBreak;
    static iconWork = iconWork;
    static iconChallenge = iconChallenge;
    static iconBreath = iconBreath;
    
    static defaultAvatar = DefaultAvatar;
    static avatar1 = DefaultAvatar1;
    static avatar2 = DefaultAvatar2;
    static avatar3 = DefaultAvatar3;

    static logo  = Logo;
    static header  = Header;
    static music = Music;
    static architecture = Architecture;
    static travel = Travel;

    static MT1 = MT1;
    static Tools_1 = Tools_1;

    static splash = splash;
    static smile = smile;
    static tlex_white = tlex_white;
    static arrow_right = arrow_right;
    static play_btn = play_btn;

    static downloadAsync(): Promise<*>[] {
        return [
            Asset.fromModule(Images.login).downloadAsync(),
            Asset.fromModule(Images.logo).downloadAsync(),
            Asset.fromModule(Images.signUp).downloadAsync(),
            Asset.fromModule(Images.walkthrough).downloadAsync(),
            Asset.fromModule(Images.profile).downloadAsync(),
            Asset.fromModule(Images.done).downloadAsync(),

            Asset.fromModule(Images.defaultAvatar).downloadAsync(),
            Asset.fromModule(Images.avatar1).downloadAsync(),
            Asset.fromModule(Images.avatar2).downloadAsync(),
            Asset.fromModule(Images.avatar3).downloadAsync(),

            Asset.fromModule(Images.music).downloadAsync(),
            Asset.fromModule(Images.architecture).downloadAsync(),
            Asset.fromModule(Images.travel).downloadAsync()
        ];
    }
}
