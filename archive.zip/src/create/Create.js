// @flow
import * as React from "react";
import {
    StyleSheet,
    View,
    Image,
    InteractionManager,
    Dimensions,
    ScrollView,
    FlatList,
    TouchableOpacity,
    StatusBar
} from "react-native";
import { Button, Text, Label, Icon } from "native-base";
import { BaseContainer, Avatar, Field, Styles, BackArrow } from "../components";
import type { ScreenProps } from "../components/Types";
import Date from "./Date";
import { FontAwesome5 } from '@expo/vector-icons';
import { Constants } from "expo";
import moment from "moment";
import variables from "../../native-base-theme/variables/commonColor";
import * as FirebaseAPI from "../../modules/firebaseAPI.js";
import * as challengesAPI from "../../modules/challengesAPI.js";
import firebase from "firebase";
import DatePicker from "react-native-datepicker";
import ButtonGD from "../components/ButtonGD";
import COLORS from "../assets/Colors";
import translate from '../../utils/language';
import FontAwesome5Icon from "react-native-vector-icons/FontAwesome5";

const { width } = Dimensions.get("window");
const height = width * 0.8;

const cha1 = require("../assets/challenges/challenge-1.png");
const cha2 = require("../assets/challenges/challenge-2.png");
const cha3 = require("../assets/challenges/challenge-3.png");
const cha4 = require("../assets/challenges/challenge-4.png");
const cha5 = require("../assets/challenges/challenge-5.png");
const cha6 = require("../assets/challenges/challenge-6.png");
const cha7 = require("../assets/challenges/challenge-7.png");
const cha8 = require("../assets/challenges/challenge-8.png");
const cha9 = require("../assets/challenges/challenge-9.png");
const cha10 = require("../assets/challenges/challenge-10.png");
const cha11 = require("../assets/challenges/challenge-11.png");
const cha12 = require("../assets/challenges/challenge-12.png");
const cha13 = require("../assets/challenges/challenge-13.png");
const cha14 = require("../assets/challenges/challenge-14.png");
const cha15 = require("../assets/challenges/challenge-15.png");


export default class Create extends React.PureComponent<ScreenProps<>> {
    state = {
        title: "",
        what: "",

        image: "1",
        update: 0,
        selectedHours: 0,
        //initial Hours
        selectedMinutes: 0,
        //initial Minutes
        title: "",
        what: "",

        currentDate: new Date(),
        markedDate: moment(new Date()).format("YYYY-MM-DD"),
        data: [
            { id: "challenge-1", image: cha1, toggle: false },
            { id: "challenge-2", image: cha2, toggle: false },
            { id: "challenge-3", image: cha3, toggle: false },
            { id: "challenge-4", image: cha4, toggle: false },
            { id: "challenge-5", image: cha5, toggle: false },
            { id: "challenge-6", image: cha6, toggle: false },
            { id: "challenge-7", image: cha7, toggle: false },
            { id: "challenge-8", image: cha8, toggle: false },
            { id: "challenge-9", image: cha9, toggle: false },
            { id: "challenge-10", image: cha10, toggle: false },
            { id: "challenge-11", image: cha11, toggle: false },
            { id: "challenge-12", image: cha12, toggle: false },
            { id: "challenge-13", image: cha13, toggle: false },
            { id: "challenge-14", image: cha14, toggle: false },
            { id: "challenge-15", image: cha15, toggle: false },
        ],
        updateSelected: false,
        imgcolor: "white"
    };



    onPressed = imageID => {
        const { data } = this.state;
        data.forEach(elem => {
            elem.toggle = false;
            if (elem.id == imageID) {
                elem.toggle = true;
            }
        });

        this.setState({ image: imageID });
        this.setState({ data: data });
        this.setState({ updateSelected: !this.state.updateSelected });
    };

    onPressed_ini = () => {
        let img = this.props.navigation.state.params.image;

        if (img != "") {
            imageID = this.props.navigation.state.params.image;
        }

        const { data } = this.state;
        data.forEach(elem => {
            elem.toggle = false;
            if (elem.id == imageID) {
                elem.toggle = true;
            }
        });

        this.setState({ image: imageID });
        this.setState({ data: data });
        this.setState({ updateSelected: !this.state.updateSelected });
    };

    componentDidMount() {
        this.focusListener = this.props.navigation.addListener(
            "didFocus",
            () => {
                if (this.props.navigation.state.params) {
                    this.setState({
                        titulo: this.props.navigation.state.params.ptitle
                    });
                    this.setState({ update: 1 });

                    this.database = firebase.database();
                    const userId = firebase.auth().currentUser.uid;
                    firebase
                        .database()
                        .ref(
                            "/Users/" +
                            userId +
                            "/Challenge/" +
                            this.props.navigation.state.params.pkey
                        )
                        .on("value", snapshot => {
                            this.setState({
                                title: snapshot.val().title,
                                what: snapshot.val().what,
                                succesful: snapshot.val().succesful,
                                why: snapshot.val().why,
                                how: snapshot.val().how,
                                problems: snapshot.val().problems,
                                date: snapshot.val().daystart,
                                image: snapshot.val().image
                            });
                        });
                    this.onPressed_ini();
                } else {
                    this.setState({
                        title: "",
                        what: "",
                        notify: "",
                        why: "",
                        image: "1"
                    });
                }
            }
        );
    }

    updateChallenge(navigation, pkey) {
        dateform = this.state.date;
        InteractionManager.runAfterInteractions(() => {

            navigation.navigate("Create2",
                {
                    ptitle: this.state.title,
                    pwhat: this.state.what,
                    pdate: dateform,
                    pimage: this.state.image,
                    psuccesful: this.state.succesful,
                    pwhy: this.state.why,
                    phow: this.state.how,
                    pproblems: this.state.problems,
                    update: 1,
                    pkey: this.props.navigation.state.params.pkey

                });
        })
    }

    deleteChallenge(navigation, pkey) {
        FirebaseAPI.deleteChallenge(pkey);

        InteractionManager.runAfterInteractions(() => {
            navigation.navigate("Home");
        });
    }

    createChallenge(navigation) {
        dateform = this.state.date;
        this.state.title,
            this.state.what,
            dateform,
            this.state.image,



            InteractionManager.runAfterInteractions(() => {
                navigation.navigate("Create2",
                    {
                        ptitle: this.state.title,
                        pwhat: this.state.what,
                        pdate: dateform,
                        pimage: this.state.image,
                    }
                );
            });
    }
    renderItem = data => (
        <ChallengeImage
            id={data.id}
            onPressItem={this.onPressed}
            image={data.image}
            active={data.toggle}
        />
    );

    handleBack() {
        this.props.navigation.goBack();
    }

    formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
        return [year, month, day].join('-');
    }    

    render(): React.Node {
        const { selectedHours, selectedMinutes } = this.state;
        const minday = moment(new Date()).format('YYYY-MM-DD');
        console.log(minday);
        let maxday = challengesAPI.today_plus(10);

        return (
            <BaseContainer
                title={translate("CreateChallenge")}
                navigation={this.props.navigation}
                scrollable
                backBtn
            >
                <StatusBar backgroundColor="white" barStyle="dark-content" />
                <BackArrow handleBackPress={() => this.handleBack()} />
                <View style={styles.screenTitleWrapper}>
                    <Text style={styles.screenTitle}>{translate("CreateChallenge")}</Text>
                </View>
                <View style={Styles.form}>
                    <Field
                        inverse
                        displayIcon iconName="md-rocket" iconColor={COLORS.white}
                        label={translate("title")}
                        value={this.state.title}
                        onChangeText={text => this.setState({ title: text })}
                        labelColor={COLORS.white}
                    />
                    <Field
                        inverse
                        displayIcon
                        displayIcon iconName="md-flash" iconColor={COLORS.white}
                        label={translate("what")}
                        value={this.state.what}
                        onChangeText={text => this.setState({ what: text })}
                        labelColor={COLORS.white}
                    />
                    {this.state.update === 0 ? (
                        <View style={styles.dateContainer}>
                            <Icon name='ios-calendar' style={{ color: COLORS.white, marginLeft: 5, marginRight: 18 }}></Icon>
                            {/* <Label style={styles.fieldLabel}>{translate("start_date")}</Label> */}
                            <DatePicker
                                style={{ width: 250 }}
                                date={this.state.date}
                                mode="date"
                                placeholder="Start date"
                                format="YYYY-MM-DD"
                                minDate={minday}
                                maxDate={maxday}
                                disabled={false}
                                // disabled = {this.state.update === 1 ? "true": "false"} 
                                confirmBtnText="Confirm"
                                cancelBtnText="Cancel"
                                //format="DD-MM-YYYY"
                                customStyles={{
                                    dateIcon: {
                                        position: "absolute",
                                        left: 0,
                                        top: 4,
                                        marginLeft: 0,
                                        opacity: 0
                                    },
                                    dateText: {
                                        fontSize: 14,
                                        borderWidth: 0,
                                        color: COLORS.white,
                                        textAlign: "left",
                                        alignSelf: "stretch"
                                    },
                                    placeholderText: {
                                        fontSize: 14,
                                        alignSelf: 'stretch',
                                        color: COLORS.white
                                    },
                                    dateInput: {
                                        borderWidth: 0,
                                        marginLeft: 0
                                    }
                                }}
                                onDateChange={date => {
                                    this.setState({ date: date });
                                }}
                            />
                        </View>
                    ) : (
                            <Label style={styles.fieldLabel}>{translate("start_date")} {this.state.date} </Label>

                        )}
                    <Label style={[styles.fieldLabel, { marginTop: 20, marginBottom: 20 }]}>{translate("icon")}</Label>
                    <FlatList
                        refresh={this.state.updateSelected}
                        numColumns={5}
                        keyExtractor={item => item.id.toString()}
                        data={this.state.data}
                        renderItem={({ item }) => this.renderItem(item)}
                    />
                </View>

                <View style={styles.buttonsContainer}>
                    {this.state.update === 1 ? (
                        <View style={{ flex: 1, alignItems: 'center' }}>
                            <TouchableOpacity style={styles.infoButton} onPress={() => this.createChallenge(this.props.navigation)}>
                                <Text style={styles.infoText}>Next</Text>
                                <FontAwesome5 name="arrow-circle-right" size={18} style={styles.infoIcon} />
                            </TouchableOpacity>
                        </View>
                        // <ButtonGD title={translate("next")} onpress={() =>
                        //     this.updateChallenge(
                        //         this.props.navigation,
                        //         this.props.navigation.state.params.pkey
                        //     )
                        // } />
                    ) : (
                            // <ButtonGD title={translate("next")} onpress={() =>
                            //     this.createChallenge(this.props.navigation)
                            // } />
                            <View style={{ flex: 1, alignItems: 'center' }}>
                                <TouchableOpacity style={styles.infoButton} onPress={() => this.createChallenge(this.props.navigation)}>
                                    <Text style={styles.infoText}>Next</Text>
                                    <FontAwesome5 name="arrow-circle-right" size={18} style={styles.infoIcon} />
                                </TouchableOpacity>
                            </View>
                        )}
                    {this.state.update === 1 ? (
                        <ButtonGD title={translate("delete")} onpress={() =>
                            this.deleteChallenge(
                                this.props.navigation,
                                this.props.navigation.state.params.pkey
                            )} />
                    ) : null}
                </View>
            </BaseContainer>
        );
    }
}

class ChallengeImage extends React.PureComponent {
    _onPress = () => {
        this.props.onPressItem(this.props.id);
    };

    render() {
        const { active } = this.props;
        const colorsel = active ? COLORS.orange : COLORS.white;

        return (
            <View style={styles.item}>
                <TouchableOpacity onPress={this._onPress}>
                    <Image
                        style={[styles.image, { tintColor: colorsel }]}
                        resizeMode="cover"
                        source={this.props.image}
                    >
                    </Image>
                    {/*  <Text>{active ? 'Activo' : 'Inactivo'}</Text> */}
                </TouchableOpacity>
            </View>
        );
    }
}



const styles = StyleSheet.create({
    container: {
        marginTop: Constants.statusBarHeight
    },
    item: {
        margin: 1,
        width: 50,
        height: 50
    },
    screenTitleWrapper: {
        marginTop: 45,
        marginBottom: 15
    },
    screenTitle: {
        textAlign: 'center',
        color: COLORS.white,
        fontSize: 20,
        fontWeight: 'bold'
    },
    paragraph: {
        fontSize: 30,
        fontWeight: "bold",
        textAlign: "center",
        color: "#fff"
    },
    image: {
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
        width: 30,
        height: 30
    },
    text: {
        color: "#fff",
        fontFamily: "Avenir-Black"
    },
    fieldLabel: {
        color: "white",
        marginTop: 5,
        marginRight: 10
    },
    dateContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 25,
        marginBottom: 5,
        borderBottomWidth: 0.9,
        borderColor: COLORS.white,
        paddingBottom: 15
    },
    buttonsContainer: {
        marginTop: 15,
        paddingBottom: 75
    },
    infoIcon: {
        color: "#ffffff",
    },
    infoButton: {
        marginTop: 10,
        paddingTop: 7,
        paddingBottom: 6,
        backgroundColor: COLORS.orange,
        borderRadius: 25,
        width: 90,
        flexDirection: 'row',
        alignContent: 'center',
        justifyContent: "center",
    },
    infoText: {
        textAlign: 'center',
        color: COLORS.white,
        fontWeight: 'bold',
        marginRight: 10,
        fontSize: 13
    }
});
