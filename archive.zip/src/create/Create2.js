// @flow
import * as React from "react";
import {
    StyleSheet,
    View,
    Image,
    InteractionManager,
    Dimensions,
    ScrollView,
    FlatList,
    TouchableOpacity,
    StatusBar
} from "react-native";
import { Button, Text, Label } from "native-base";

import { BaseContainer, Avatar, Field, Styles } from "../components";
import type { ScreenProps } from "../components/Types";

import Date from "./Date";
import { Constants } from "expo";

import moment from "moment";

import variables from "../../native-base-theme/variables/commonColor";

import * as FirebaseAPI from "../../modules/firebaseAPI.js";
import * as challengesAPI from "../../modules/challengesAPI.js";

import firebase from "firebase";

import DatePicker from "react-native-datepicker";

import ButtonGD from "../components/ButtonGD";
import COLORS from "../assets/Colors";
import translate from '../../utils/language';

const { width } = Dimensions.get("window");
const height = width * 0.8;

const cha1 = require("../assets/challenges/challenge-1.png");
const cha2 = require("../assets/challenges/challenge-2.png");
const cha3 = require("../assets/challenges/challenge-3.png");
const cha4 = require("../assets/challenges/challenge-4.png");
const cha5 = require("../assets/challenges/challenge-5.png");
const cha6 = require("../assets/challenges/challenge-6.png");
const cha7 = require("../assets/challenges/challenge-7.png");
const cha8 = require("../assets/challenges/challenge-8.png");
const cha9 = require("../assets/challenges/challenge-9.png");
const cha10 = require("../assets/challenges/challenge-10.png");
const cha11 = require("../assets/challenges/challenge-11.png");
const cha12 = require("../assets/challenges/challenge-12.png");
const cha13 = require("../assets/challenges/challenge-13.png");
const cha14 = require("../assets/challenges/challenge-14.png");

export default class Create2 extends React.PureComponent<ScreenProps<>> {
    state = {
        title: "",
        what: "",
        notify: "",
        why: "",
        update: 0,
        how: "",
        succesful: "",
        problems: "",
    };

    componentDidMount() {
        this.focusListener = this.props.navigation.addListener(
            "didFocus",
            () => {
                console.log(this.props.navigation.state.params.pkey);
                console.log(this.props.navigation.state.params.pwhy);
                if (this.props.navigation.state.params.pkey) {
                    console.log("entro");
                    this.setState({
                        title: this.props.navigation.state.params.ptitle,
                        what: this.props.navigation.state.params.pwhat,
                        succesful: this.props.navigation.state.params.psuccesful,
                        why: this.props.navigation.state.params.pwhy,
                        how: this.props.navigation.state.params.phow,
                        problems: this.props.navigation.state.params.pproblems,
                        date: this.props.navigation.state.params.pdate,
                        image: this.props.navigation.state.params.pimage,
                    });
                    this.setState({ update: 1 });
                } else {
                    this.setState({ update: 0 });
                };
            })
    }

    updateChallenge(navigation, pkey) {

        FirebaseAPI.updateChallenge(
            pkey,
            this.state.title,
            this.state.what,
            this.state.why,
            this.state.how,
            this.state.succesful,
            this.state.problems,
            this.state.image
        );

        InteractionManager.runAfterInteractions(() => {
            navigation.navigate("Challenges");
        });
    }

    createChallenge(navigation) {
        this.state.title = this.props.navigation.state.params.ptitle,
            this.state.what = this.props.navigation.state.params.pwhat,
            this.state.date = this.props.navigation.state.params.pdate,
            this.state.image = this.props.navigation.state.params.pimage,

            FirebaseAPI.createChallenge(
                this.state.title,
                this.state.what,
                this.state.why,
                this.state.how,
                this.state.succesful,
                this.state.problems,
                this.state.date,
                this.state.image
            );

        InteractionManager.runAfterInteractions(() => {
            navigation.navigate("Challenges");
        });
    }

    render(): React.Node {
        const { selectedHours, selectedMinutes } = this.state;
        let minday = challengesAPI.today();
        let maxday = challengesAPI.today_plus(10);

        return (
            <BaseContainer
                title={translate("CreateChallenge")}
                navigation={this.props.navigation}
                scrollable
                backBtn
            >
                <StatusBar backgroundColor="white" barStyle="dark-content" />
                <View style={Styles.form}>

                    <Field
                        inverse
                        label={translate("how")}
                        value={this.state.how}
                        onChangeText={text => this.setState({ how: text })}
                        labelColor={COLORS.white}
                    />
                    <Field
                        inverse
                        label={translate("why")}
                        value={this.state.why}
                        onChangeText={text => this.setState({ why: text })}
                        labelColor={COLORS.white}
                    />
                    <Field
                        inverse
                        label={translate("success")}
                        value={this.state.succesful}
                        onChangeText={text =>
                            this.setState({ succesful: text })
                        }
                        labelColor={COLORS.white}
                    />
                    <Field
                        inverse
                        label={translate("problems")}
                        value={this.state.problems}
                        onChangeText={text => this.setState({ problems: text })}
                        labelColor={COLORS.white}
                    />
                </View>

                <View style={styles.buttonsContainer}>
                    {this.state.update === 1 ? (
                        <ButtonGD title={translate("update")} onpress={() =>
                            this.updateChallenge(
                                this.props.navigation,
                                this.props.navigation.state.params.pkey
                            )
                        } />
                    ) : (
                            <ButtonGD title="Add" onpress={() =>
                                this.createChallenge(this.props.navigation)
                            } />
                        )}
                    {this.state.update === 1 ? (
                        <ButtonGD title="Delete" onpress={() =>
                            this.deleteChallenge(
                                this.props.navigation,
                                this.props.navigation.state.params.pkey
                            )} />
                    ) : null}
                </View>
            </BaseContainer>
        );
    }
}

class ChallengeImage extends React.PureComponent {
    _onPress = () => {
        this.props.onPressItem(this.props.id);
    };

    render() {
        const { active } = this.props;
        const colorsel = active ? "yellow" : "white";

        return (
            <View style={styles.item}>
                <TouchableOpacity onPress={this._onPress}>
                    <Image
                        style={[styles.image, { tintColor: colorsel }]}
                        resizeMode="cover"
                        source={this.props.image}
                    >
                    </Image>
                    {/*  <Text>{active ? 'Activo' : 'Inactivo'}</Text> */}
                </TouchableOpacity>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        marginTop: Constants.statusBarHeight
    },
    item: {
        margin: 1,
        width: 70
    },
    paragraph: {
        fontSize: 30,
        fontWeight: "bold",
        textAlign: "center",
        color: "#fff"
    },
    image: {
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
        width: 50,
        height: 50
    },
    text: {
        color: "#fff",
        fontFamily: "Avenir-Black"
    },
    fieldLabel: {
        color: "white",
        marginTop: 10,
        marginRight: 10
    },
    dateContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 30,
        marginBottom: 5
    },
    buttonsContainer: {
        marginTop: 15,
        paddingBottom: 75
    }
});