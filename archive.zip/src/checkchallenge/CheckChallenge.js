// @flow

import * as React from "react";
import {View, Image, StyleSheet, Dimensions, Animated,TouchableWithoutFeedback, Alert} from "react-native";
import {H1, Text, Button} from "native-base";

import {BaseContainer, TaskOverview, Images, Styles} from "../components";
import type {ScreenProps} from "../components/Types";
import firebase from 'firebase';
import * as challengesAPI from "../../modules/challengesAPI.js";

import variables from "../../native-base-theme/variables/commonColor";




export default class CheckChallenge extends React.PureComponent<ScreenProps<>> {

  constructor(props) {
        
          super(props);
              this.state = {
                  listingData: [],
                  completed: '',
                  abandoned:'',
                  left:'',
                  day:'',
                  frase:'',
                  animValue: new Animated.Value(250),
                  currentDate: new Date(),
              }
         }

 
         
  handleSelect = () => {
    this.Update()  
    this.state.animValue._value > 250
      ? Animated.timing(this.state.animValue, {
          toValue: 250,
          duration: 500
        }).start()
      : Animated.timing(this.state.animValue, {
          toValue: 450,
          duration: 500
        })
        .start(() =>  {this.props.navigation.navigate ('Home');}); 
        //{this.props.navigation.navigate("Home"});

  };

  renderRectangle = () => {
    let rotateAnimation = this.state.animValue.interpolate({
        inputRange: [250, 450],
        outputRange: ['0deg', '360deg']
    });

    const customStyle = {
      height: this.state.animValue,
      transform:[{rotate:rotateAnimation}]
    };
    return (
        <Animated.View style={[style.rectangle, customStyle]}>
          <TouchableWithoutFeedback onPress={() => this.handleSelect()}>
            <View style={{ flex: 1 }} >
            <Image source={Images.done} resizeMode="cover" style={[StyleSheet.absoluteFill, style.img]} />
            </View>
          </TouchableWithoutFeedback>
        </Animated.View>
      );
    };


    componentDidMount ()
{

        console.log(this.props.navigation.state.params.pkey);
        this.setState({key:  this.props.navigation.state.params.pkey});
        
        this.focusListener = this.props.navigation.addListener("didFocus", () => { 
        
            this.database = firebase.database();
            const userId = firebase.auth().currentUser.uid;
            firebase.database().ref("/Users/" + userId + '/Challenge/' + this.props.navigation.state.params.pkey )
            .on("value", snapshot => {
          
            this.setState({completed: snapshot.val().completed,
                          abandoned: snapshot.val().abandoned,
                          left: snapshot.val().left,
                          day: snapshot.val().day, 
                          daystart: snapshot.val().daystart,
                          day1:snapshot.val().day1,
                          day2:snapshot.val().day2,
                          day3:snapshot.val().day3,
                          day4:snapshot.val().day4,
                          day5:snapshot.val().day5,
                          day6:snapshot.val().day6,
                          day7:snapshot.val().day7,
                          day8:snapshot.val().day8,
                          day9:snapshot.val().day9,
                          day10:snapshot.val().day10,
                          day11:snapshot.val().day11,
                          day12:snapshot.val().day12,
                          day13:snapshot.val().day13,
                          day14:snapshot.val().day14,
                          day15:snapshot.val().day15,
                          day16:snapshot.val().day16,
                          day17:snapshot.val().day17,
                          day18:snapshot.val().day18,
                          day19:snapshot.val().day19,
                          day20:snapshot.val().day20,
                          day21:snapshot.val().day21,
                          })
          } )


          var CurrentDay = 'day' + this.state.day.toString();

          switch(CurrentDay) {
    
            case 1: this.setState({frase: 'Your limitation—it’s only your imagination.'});  break;
            case 2: this.setState({frase: 'Difference between motivation and inspiration - Motivation is external and short lived. Inspiration is internal and lifelong'});  break;
            case 3: this.setState({frase: 'Life is nothing to be very serious about. Life is a ball in your hands to play with. Don’t hold on to the ball.'});  break;
            case 4: this.setState({frase: 'If you can win over your mind, you can win over the whole world.'});  break;
            
        
      
     
      
        }
      }       )


}       

    Update () {
       
       

        
        var CurrentDay = 'day' + this.state.day.toString();
        
      
       
        const userId = firebase.auth().currentUser.uid;
        this.database = firebase.database();
        
        firebase.database().ref(("/Users/" + userId + '/Challenge/' 
             + this.props.navigation.state.params.pkey))
            .update({[CurrentDay] : 1,  completed: this.state.completed+1}); 
      }

    render(): React.Node {
        
        let cant=0;
        for (var i=1; i<21; i++){
          if (this.state['day' + i] ==0 && i < this.state.day ){overdue=overdue+1} 
          cant= cant + this.state['day' + i]
        }

        let currentday = challengesAPI.current_day(this.state.daystart);
        let finished = challengesAPI.finished(currentday);
        let daychecked = this.state['day' + currentday] ;
        let overdue = challengesAPI.abandoned (finished, daychecked, cant, currentday);
        
        this.setState({day:currentday});
        this.setState({titulo:  this.props.navigation.state.params.ptitle});
        
        var status = (cant/21)*100;
        this.setState({completed:cant})
        status=status.toFixed(2);
      
      
        return (
            <BaseContainer title={this.props.title} navigation={this.props.navigation} scrollable>
                
                <View style={style.row}>
                     <H1>{this.state.titulo} Day: {currentday} </H1> 
                    <Text style={Styles.textCentered}>Good job! {status}% more completed tasks</Text>
                </View>

                <TaskOverview completed={cant}  overdue={overdue} />

                {this.state['day' + currentday] ==1  ? (
                
                  <View style={style.row}>
                 
                 <Text style={Styles.textCentered}>You've just check this challenge today. See you tomorrow</Text>
             </View>
                ) : this.renderRectangle()}               
               
            </BaseContainer>
        );
    }
}

const {width} = Dimensions.get("window");
const style = StyleSheet.create({
    img: {
        width,
        height: width * (500 / 550),
        resizeMode: "cover"
    },
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
      },
    row: {
        justifyContent: "center",
        alignItems: "center",
        padding: variables.contentPadding * 2
    },
    rectangle: {
       
        width: 250
      }
});