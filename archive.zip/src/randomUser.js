//import randomBoolean from './randomBoolean'
//import randomNumber from './randomNumber'

export default function (size) {
  //  const gender = randomBoolean() ? 'men': 'women';
     const gender ='men';
    const number = Math.floor(50);
    if (!size) {
        return `https://randomuser.me/api/portraits/${gender}/${number}.jpg`;
    }
    return `https://randomuser.me/api/portraits/${size}/${gender}/${number}.jpg`;
}
