import React, { Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { Constants, WebBrowser } from 'expo';
import {FAQ,Question} from '../components/Question'
import { BaseContainer, Images } from "../components";
import COLORS from "../assets/Colors";

// define some bullets
const bullets = [
  'you could say hello',
  'Open an issue',
  'making a pull request',
  'or give me more ideas to improve this component'
]
// define an action
const action_example = () => {
  WebBrowser.openBrowserAsync(
      'https://github.com/Olcina/react-native-faq'
    );
}

const goTo = (link) => {
  WebBrowser.openBrowserAsync(
      link
    );
}

const questions = [
      {
        question:"How can I meditate?",
        reply:"Go to section Meditation",
        bullets: bullets ,
    
      },
      {
        question : "Don't you know how to start?",
        reply : "Please be patiente and relax",
        
        
      }
    ]

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default class Faq1 extends Component {
  render() {
    return (
      /*  <BaseContainer title={'FAQ'} scrollable  startGradient={COLORS.lightblue} endGradient={COLORS.white}>
       */ 
        <BaseContainer title={'FAQ'}  scrollable startGradient={COLORS.lightblue} endGradient={COLORS.white}>    
      <View style={styles.container}>
           
        <View>
          
          <FAQ 
           
            questions={questions}
          />

        </View>
        
        
        
        </View>
         
        </BaseContainer> 
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
   
    
    padding: 8,
  }
});
