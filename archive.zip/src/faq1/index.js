// @flow
export {default as Faq1} from "./Faq1";
