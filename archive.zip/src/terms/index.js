// @flow
export {default as Terms} from "./Terms";
