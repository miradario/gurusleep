import React, { Component } from 'react';
import { StyleSheet, View, ScrollView, Text, Image, PanResponder, Dimensions, Animated, StatusBar} from 'react-native';
import { BaseContainer, Images } from "../components";
import COLORS from "../assets/Colors";
import { AnimatedView } from "../components/Animations";

export default class Terms extends Component {

    render() {
        return (
            <BaseContainer title={'Terms and Condition'} scrollable  startGradient={COLORS.lightblue} endGradient={COLORS.white}>
                <StatusBar backgroundColor="white" barStyle="dark-content" />
                <AnimatedView style={styles.contentWrapper}>
                    <Text style={styles.mainTitle}>Data protection information</Text>
                    <Text style={styles.mainIntro}>
                        Use of this website may involve processing personal data. We would like to give you an overview of this processing with the following information so that you can understand this processing. In order to ensure fair processing, we would also like to inform you about your rights under the European General Data Protection Regulation (GDPR). TLEX GmbH (hereinafter referred to as "we" or "us") is responsible for data processing..
                    </Text>
                    <Text style={styles.subTitle}>Content</Text>
                            <Bullet content = "General information"/>
                            <Bullet content = "Contact"/>
                            <Bullet content = "a. Contact" />
                            <Bullet content = "b. Representatives in the EU" />
                            <Bullet content = "c. Legal basis" />
                            <Bullet content = "d. Duration of storage" />
                            <Bullet content = "e. Technical service provider" />
                            <Bullet content = "f. Data transmission to the USA" />
                            <Bullet content = "2. Processing of server log files" />
                            <Bullet content = "3. Registration, login and use" />
                            <Bullet content = "4. Cookies" />
                            <Bullet content = "5. Google Analytics" />
                            <Bullet content = "6. Vimeo" />
                            <Bullet content = "7. Processing when exercising your rights acc. Art. 15 to 22 GDPR" />
                            <Bullet content = "8. Your rights 9. Right to" />

                           
                    
                </AnimatedView>
            </BaseContainer >
        );
    }
}

class Bullet extends React.Component {

    render() {
        const { content } = this.props
        return (
            <View style={styles.bulletWrapper}>
                <Text style={styles.bullet}>{'\u2022'}</Text>
                <Text style={styles.bulletText}>{content}</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'gray',
        flex: 1
    },
    contentWrapper: {
        padding: 15,
        marginBottom: 55
    },
    mainTitle: {
        color: '#656669',
        fontSize: 20,
        marginTop: 15
    },
    mainIntro: {
        color: COLORS.gray,
        fontSize: 14,
        marginTop: 18
    },
    subTitle: {
        fontSize: 17,
        color: '#000000',
        marginTop: 30
    },
    moduleWrapper: {
        flexDirection: 'row', 
        marginTop: 20
    },
    moduleWhite: {
        flex: 3,
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderLeftWidth: 0,
        borderTopColor: COLORS.blue,
        borderRightColor: COLORS.blue,
        borderBottomColor: COLORS.blue,
        padding: 15,
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    moduleOrange: {
        flex: 1,
        backgroundColor: COLORS.orange,
        borderWidth: 1,
        borderRightWidth: 0,
        borderTopColor: COLORS.white,
        borderLeftColor: COLORS.white,
        borderBottomColor: COLORS.white,
        padding: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    moduleOrangeImg: {
        marginTop: 20
    },
    moduleOrangeTitle: {
        color: COLORS.white
    },
    moduleWhiteTitle: {
        color: COLORS.gray,
        fontWeight: 'bold',
        marginTop: 15
    },
    bulletWrapper: {
        flexDirection: 'row',
        marginTop: 12
    },
    bullet: {
        color: COLORS.gray,
        marginRight: 5
    },
    bulletText: {
        color: COLORS.gray,
        marginRight: 5
    }
});
