// @flow
import moment from "moment";
import * as React from "react";
import { View, TouchableOpacity, Image, StyleSheet, Dimensions, ActivityIndicator, Alert } from "react-native";
import { H1, H3, Button, Text, Icon } from "native-base";
import { BaseContainer, Images, Styles, BackArrow } from "../components";
import { checkFav, addFav, removeFav } from "../../modules/firebaseAPI";
import type { ScreenProps } from "../components/Types";
import { Ionicons } from '@expo/vector-icons';
import { Constants } from 'expo';
import { Audio } from 'expo-av';
import variables from "../../native-base-theme/variables/commonColor";
import COLORS from "../assets/Colors";


const source = { uri: 'https://firebasestorage.googleapis.com/v0/b/aprendiendofirebase-9aa43.appspot.com/o/en%2FKriya%2FTlexKriyaMusicInPrana_64kb.mp3?alt=media&token=67188163-ba1c-403d-af9f-c1ae77a8d02a', };
const btnPlay = require('../../assets/images/btn-play.png');
const btnPause = require('../../assets/images/btn-pause.png');

export default class AudiosPlayer extends React.PureComponent<ScreenProps<>> {

  state = {
    playingStatus: "LOADING",
    playButtonImg: btnPlay,
    controlsVisible: false,
    isFav: false,
    startTime: 0,
    endTime: 0,
    elapsed: 0,
    elpasedMs: 0,
    elapsedPercent: 0,
    elapsedTime: '00:00'
  }

  start() {
    this.setState({ startTime: new Date() });
  }

  end() {
    let endTime = new Date();
    let timeDiff = endTime - this.state.startTime; //in ms
    // strip the ms
    timeDiff /= 1000;
    // get seconds 
    let seconds = Math.round(timeDiff);
    this.setState({ elapsed: seconds })
  }

  async checkIfFav() {
    let isFav = await checkFav(this.props.navigation.getParam('key'))
    this.setState({ isFav: isFav })
  }

  promptDiscard = () => {
    const title = 'Discard current meditation' //+ this.props.navigation.state.params.title;
    const message = 'Are you sure?';
    const buttons = [
      { text: 'Cancel', type: 'cancel' },
      { text: 'Discard', onPress: () => this.handleBack() },
    ];
    Alert.alert(title, message, buttons);
  }

  promptComplete = () => {
    const title = 'Complete meditation' //+ this.props.navigation.state.params.title;
    const message = 'Are you sure?';
    const buttons = [
      { text: 'Cancel', type: 'cancel' },
      { text: 'Complete', onPress: () => this.handleFinish() },
    ];
    Alert.alert(title, message, buttons);
  }

  componentDidMount() {
    const { navigation } = this.props;
    this.blurListener = navigation.addListener("willBlur", () => {
      if (this.sound != null) {
        this.sound.pauseAsync();
        if (this.state.playingStatus == 'PLAYING') {
          this.setState({
            playingStatus: 'PAUSED',
            playButtonImg: btnPlay
          });
        }
      }
    });

    this.focusListener = this.props.navigation.addListener(
      "didFocus",
      () => {
        this.checkIfFav()
      }
    )

    Audio.setAudioModeAsync({
      playsInSilentModeIOS: true,
      allowsRecordingIOS: false,
      staysActiveInBackground: true,
      interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DO_NOT_MIX,
      shouldDuckAndroid: false,
      interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DO_NOT_MIX,
      playThroughEarpieceAndroid: true
    })
    this._playRecording();
  }

  componentWillUnmount() {
    this.sound.pauseAsync();
    this.blurListener.remove();
  }

  async _playRecording() {
    const { sound } = await Audio.Sound.createAsync(
      source,
      {
        shouldPlay: true,
        isLooping: false,
      },
    );
    sound.setOnPlaybackStatusUpdate(this._onPlaybackStatusUpdate);
    this.start();
    this.sound = sound;
    this.setState({ playingStatus: 'PLAYING', playButtonImg: btnPause, controlsVisible: true });
  }

  async _pauseAndPlayRecording() {
    if (this.sound != null) {
      if (this.state.playingStatus == 'PLAYING') {
        await this.sound.pauseAsync();
        this.setState({
          playingStatus: 'PAUSED',
          playButtonImg: btnPlay
        });
      } else {
        await this.sound.playAsync();
        this.setState({
          playingStatus: 'PLAYING',
          playButtonImg: btnPause
        });
      }
    }
  }

  _syncPauseAndPlayRecording() {
    if (this.sound != null) {
      if (this.state.playingStatus == 'playing') {
        this.sound.pauseAsync();
      } else {
        this.sound.playAsync();
      }
    }
  }

  _zeroFill( number, width )
  {
    width -= number.toString().length;
    if ( width > 0 )
    {
      return new Array( width + (/\./.test( number ) ? 2 : 1) ).join( '0' ) + number;
    }
    return number + ""; // always return a string
  }

  _msToTime(ms) {
    let seconds = ms / 1000;
    //let hours = parseInt( seconds / 3600 ); // 3,600 seconds in 1 hour
    //seconds = seconds % 3600; // seconds remaining after extracting hours
    let minutes = Math.trunc( seconds / 60 );
    seconds = Math.trunc(seconds % 60);
    return this._zeroFill(minutes, 2) + ":" + this._zeroFill(seconds, 2);
  }

  _playAndPause = () => {
    this._pauseAndPlayRecording();
  }

  _onPlaybackStatusUpdate = playbackStatus => {
    if (playbackStatus.isLoaded) {
      let timeElapsed = this._msToTime(playbackStatus.positionMillis)
      let audioProgress = playbackStatus.positionMillis / playbackStatus.playableDurationMillis
      this.setState({elapsedPercent: audioProgress, elapsedTime: timeElapsed, elapsedMs: playbackStatus.positionMillis})
    }
  };

  handleHeartClick = async () => {
    let { isFav } = this.state
    let category = this.props.navigation.getParam('category')
    let key = this.props.navigation.getParam('key')
    if (isFav) {
      this.setState({ isFav: false })
      await removeFav(key)
    } else {
      this.setState({ isFav: true })
      await addFav(key, 'audio', category)
    }
  }

  handleBack() {
    this.props.navigation.goBack();
  }

  handleFinish() {
    this.end();
    let secondsElapsed = this.state.elapsedMs / 1000
    let m = Math.floor(secondsElapsed % 3600 / 60);
    var s = Math.floor(secondsElapsed % 3600 % 60);
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    let minutes = mDisplay + sDisplay;
    this.props.navigation.navigate("Finished", {
      elapsed: minutes, 
      photo: this.props.navigation.getParam('photo', ''),
      ptitle: this.props.navigation.getParam('ptitle', '')
    });
  }

  capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  render(): React.Node {
    const { navigation } = this.props;
    const url = navigation.getParam('url', 'some default value');
    const photo = navigation.getParam('photo', '');
    const title = navigation.getParam('title', '');
    const today = moment();
    const date = today.format("MMMM D");
    const { isFav, elapsedPercent, elapsedTime} = this.state

    let heartColor = COLORS.white
    if (isFav) { heartColor = COLORS.orange }

    Images.yoga = photo;
    //source.uri = 'https://www.gesundes-und-achtsames-fuehren.de/assets/audios/' + url;

    return (
      <BaseContainer title="Meditate" navigation={this.props.navigation} backBtn noPadding>
        <View style={style.container}>
          {/* <TouchableOpacity style={style.btnFavWrapper} onPress={this.handleHeartClick}>
            <View style={{ height: 35, width: 35, borderRadius: 50, backgroundColor: COLORS.lightgray, alignItems: 'center', justifyContent: 'center', paddingTop: 5 }}>
              <Ionicons name={'ios-heart'} color={heartColor} size={25} />
            </View>
          </TouchableOpacity> */}
          <View style={style.imgWrapper}>
            <Image source={{ uri: photo }} style={style.img} />
            <Text style={style.audioTitle}>{this.capitalize(this.props.navigation.state.params.ptitle)}</Text>
            <View style={style.seekBarWrapper}>
              <View style={{flex: 1}}>
                <Text style={{textAlign: 'center'}}>{elapsedTime}</Text>
                </View>
              <View style={style.seekBarBackground}>
                <View style={[{flex: elapsedPercent}, style.seekBarProgress]}></View>
              </View>
            </View>
          </View>
          {this.state.controlsVisible ? (
            <View style={style.indicator}>
              <TouchableOpacity onPress={this._playAndPause}>
                <Image style={style.button} source={this.state.playButtonImg} />
              </TouchableOpacity>
            </View>
          ) : null}
          {this.state.playingStatus === 'LOADING' ? (
            <View style={style.indicator}>
              <ActivityIndicator size="large" color="#ffffff" />
            </View>
          ) : null}
        </View>
        <View style={{ flexDirection: 'row', marginTop: 25, height: 100}}>
          <View style={style.discard}>
            <TouchableOpacity onPress={this.promptDiscard} >
              <View style={{ width: 40, height: 40, borderRadius: 90, backgroundColor: COLORS.orange, alignSelf: 'center', justifyContent: 'center', alignItems: 'center' }}>
                <Icon style={style.discardIcon} name={'ios-close-circle-outline'} />
              </View>
              <Text style={{ marginTop: 10 }}>
                <Text style={{ fontWeight: "bold" }}> Discard</Text>
              </Text>
            </TouchableOpacity >
          </View>
          <View style={style.Complete}>
            <TouchableOpacity onPress={this.promptComplete} >
              <View style={{ width: 40, height: 40, borderRadius: 90, backgroundColor: COLORS.orange, alignSelf: 'center', justifyContent: 'center', alignItems: 'center' }}>
                <Icon style={style.CompleteIcon} name={'ios-checkmark-circle-outline'} color={COLORS.orange} />
              </View>
              <Text style={{ marginTop: 10 }}>
                <Text style={{ fontWeight: "bold" }}> Complete</Text>
              </Text>
            </TouchableOpacity >
          </View>
        </View>
      </BaseContainer>
    );
  }
}

const { width } = Dimensions.get("window");
const { height } = Dimensions.get("window");
const style = StyleSheet.create({
  audioTitle: {
    position: 'absolute',
    zIndex: 100,
    left: 0,
    right: 0,
    top: 80,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    color: COLORS.white
  },  
  container: {
    flex: 4,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent'
  },
  discard: {
    flex: 1,
    alignItems: 'flex-start',
    paddingLeft: 25
  },
  Complete: {
    flex: 1,
    alignItems: 'flex-end',
    paddingRight: 25
  },
  imgWrapper: {
    alignSelf: 'stretch',
    flex: 1
  },
  img: {
    resizeMode: 'cover',
    ...StyleSheet.absoluteFillObject,
  },
  btnFavWrapper: {
    position: 'absolute',
    zIndex: 1000,
    top: 15,
    right: 15
  },
  row: {
    justifyContent: "center",
    alignItems: "center",
    padding: variables.contentPadding * 2
  },
  indicator: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    justifyContent: "center",
    alignItems: 'center'
  },
  button: {
    width: 75,
    height: 75,
    opacity: 0.85
  },
  section: {
    padding: variables.contentPadding * 2,
    borderBottomWidth: variables.borderWidth,
    borderColor: variables.listBorderColor,
    flexDirection: "row",
    alignItems: "center"
  },
  seekBarWrapper: {
    position: 'absolute', 
    left: 0, 
    right: 0, 
    bottom: 0, 
    height: 50, 
    backgroundColor: 'rgba(0, 0, 0, 0.4)', 
    zIndex: 100, 
    alignItems: 'center', 
    justifyContent: 'flex-start', 
    flexDirection: 'row'
  },
  seekBarBackground: {
    flex: 5, 
    height: 10, 
    backgroundColor: COLORS.lightgray,
    flexDirection: 'row',
    marginRight: 10
  },
  seekBarProgress: {
    height: 10, 
    backgroundColor: COLORS.orange
  }
});

// https://github.com/expo/expo/issues/1141