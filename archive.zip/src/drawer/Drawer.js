// @flow
import * as React from "react";
import { View, SafeAreaView, StyleSheet, Image, TouchableHighlight, InteractionManager, StatusBar } from "react-native";
import { Button, Icon, Header, Text, Left, Title, Body, Right } from "native-base";
import { Foundation as Iconfound } from 'react-native-vector-icons';
import Constants from "expo-constants";
import { LinearGradient } from 'expo-linear-gradient';
import { DrawerActions } from "react-navigation";
import { Images, Styles, WindowDimensions, Container } from "../components";
import type { NavigationProps } from "../components/Types";

import variables from "../../native-base-theme/variables/commonColor";
import * as FirebaseAPI from '../../modules/firebaseAPI.js';
import COLORS from "../assets/Colors";
import translate from '../../utils/language';

export default class Drawer extends React.Component<NavigationProps<>> {

    go(key: string) {
        this.props.navigation.navigate(key);
    }

    logout(navigation) {
        FirebaseAPI.logoutUser()
        InteractionManager.runAfterInteractions(() => {
            this.props.navigation.navigate('Login')
        })
    }


    login = () => {
        this.props.navigation.navigate("Login");
    }
    render(): React.Node {
        const { navigation } = this.props;
        return (
            <SafeAreaView style={{ backgroundColor: COLORS.blue, flex: 1 }}>
                <StatusBar backgroundColor="white" barStyle="dark-content" />
                <LinearGradient
                    colors={[COLORS.blue, COLORS.lightblue]}
                    style={[StyleSheet.absoluteFill, style.gradientBg]}
                    start={[1, 0]}
                    end={[1, 1]}>
                </LinearGradient>
                <View style={style.closeBar}>
                    <Button transparent onPress={() => this.props.navigation.dispatch(DrawerActions.toggleDrawer())}>
                        <Icon name="ios-close" style={style.closeIcon} />
                    </Button>
                </View>
                <View style={style.itemContainer}>
                    <View style={style.row}>
                        <DrawerItem {...{ navigation }} navegar="Micromoments" name={translate("micromoments")} icon="ios-hourglass" left />
                        <DrawerItem {...{ navigation }} navegar="Tools" name={translate("tools")} icon="ios-hammer" />
                    </View>
                    <View style={style.row}>
                        <DrawerItem {...{ navigation }} navegar="Teachers" name={translate("teachers")} icon="ios-people" left />
                        <DrawerItem {...{ navigation }} navegar="Resources" name={translate("workshop")} icon="ios-photos" />
                    </View>
                    <View style={style.row}>
                        <DrawerItem {...{ navigation }} navegar="Settings" name={translate("settings")} icon="ios-settings" left />
                        <DrawerItem {...{ navigation }} navegar="Faq1" name="FAQ" icon="ios-information-circle" />
                    </View>
                    <View style={style.row}>
                        <DrawerItem {...{ navigation }} navegar="Contact" name={translate("contactus")} icon="ios-mail" left />
                        <DrawerItem {...{ navigation }} navegar="Terms" name={translate("terms")} icon="ios-paper" />
                    </View>
                </View>

            </SafeAreaView>
        );
    }
}

type DrawerItemProps = NavigationProps<> & {
    name: string,
    icon: string,
    left?: boolean
};

class DrawerItem extends React.PureComponent<DrawerItemProps> {
    render(): React.Node {
        const { name, navegar, navigation, icon, left } = this.props;
        const navState = this.props.navigation.state;
        const active = navState.routes[navState.index].key === navegar;
        const props = {
            onPress: () => navigation.navigate(navegar),
            style: [style.item]
        };
        return (
            <TouchableHighlight {...props} activeOpacity={0.5} underlayColor="rgba(255, 255, 255, .2)">
                <View style={[Styles.center, Styles.flexGrow, { borderRadius: 25, margin: 10 }]}>
                    <LinearGradient
                        style={[Styles.center, Styles.flexGrow, { flex: 1, borderRadius: 25, alignSelf: 'stretch', borderColor: COLORS.white, borderWidth: 1}, ]}
                        colors={[COLORS.lightblue, COLORS.lightblue]}
                        start={[1, 0]}
                        end={[1, 1]}>
                        <Icon name={icon} style={{ color: COLORS.orange }} />
                        <Text style={{ marginTop: variables.contentPadding, color: COLORS.black }}>{name}</Text>
                        {
                            active && <View style={style.dot} />
                        }
                    </LinearGradient>
                </View>
            </TouchableHighlight>
        );
    }
}

const style = StyleSheet.create({
    img: {
        ...StyleSheet.absoluteFillObject,
        width: WindowDimensions.width,
        height: WindowDimensions.height - Constants.statusBarHeight,
        top: Constants.statusBarHeight
    },
    gradientBg: {
        flex: 1,
        alignItems: 'center',
        width: WindowDimensions.width,
        top: Constants.statusBarHeight
    },
    closeIcon: {
        fontSize: 50,
        color: variables.listBorderColor
    },
    closeBar: {
        alignSelf: 'flex-start',
        height: 40,
        marginLeft: 10
    },
    itemContainer: {
        flex: 1
    },
    row: {
        flex: 1,
        flexDirection: "row",
        borderColor: variables.listBorderColor,
        // borderBottomWidth: variables.borderWidth
    },
    item: {
        flex: 1,
        justifyContent: "center",
        alignItems: "stretch",
        // borderColor: variables.listBorderColor
    },
    dot: {
        backgroundColor: "white",
        height: 10,
        width: 10,
        borderRadius: 5,
        position: "absolute",
        right: variables.contentPadding,
        top: variables.contentPadding,
        alignSelf: "flex-end"
    }
});
