// @flow
/* eslint-disable no-console, global-require, no-nested-ternary, react/jsx-indent */
import * as React from "react";
import { Dimensions, View, Platform, AsyncStorage, Image} from "react-native";

import { StyleProvider } from "native-base";
import {
    createAppContainer, createSwitchNavigator, createDrawerNavigator, createBottomTabNavigator, createStackNavigator, DrawerActions
} from "react-navigation";
import createAnimatedSwitchNavigator from 'react-navigation-animated-switch';
import { createMaterialBottomTabNavigator } from 'react-navigation-material-bottom-tabs';
import { Transition } from 'react-native-reanimated';
import { AppLoading } from "expo";
import * as Font from "expo-font";
import Icon from 'react-native-vector-icons/Ionicons';
import { FontAwesome5 } from 'react-native-vector-icons';
import { Images } from "./src/components";
import { Login } from "./src/login";
import { SignUp } from "./src/sign-up";
import { Walkthrough } from "./src/walkthrough";
import { Drawer } from "./src/drawer";
import { Home } from "./src/home";
import { Modal } from "./src/modal";
import { Resources } from "./src/resources";
import { BreathTools } from "./src/breathtools";
import { Challenges } from "./src/challenges";
import { Settings } from "./src/settings";
import { Terms } from "./src/terms";
import { Create } from "./src/create";
import { Create2 } from "./src/create";
import { Pdf } from "./src/pdf";
import { Faq1 } from "./src/faq1";
import { Player } from "./src/player";
import { Meditate } from "./src/meditate";
import { Breath } from "./src/meditate";
import { Work } from "./src/meditate";
import { InAppPurchase } from "./src/meditate";

import { Splash } from "./src/splash";

import { Audios } from "./src/audios";
import { AudiosPlayer } from "./src/audios";
import { Finished } from "./src/audios";
import { Relaxation } from "./src/relaxation";
import { Mountain } from "./src/mountain";
import { Teachers } from "./src/teachers";
import { Micromoments } from "./src/micromoments";
import { Tools } from "./src/tools";
import { Contact } from "./src/contact";

import getTheme from "./native-base-theme/components";
import variables from "./native-base-theme/variables/commonColor";
import firebase from 'firebase';
import COLORS from './src/assets/Colors'
import i18n from 'i18n-js'
import translate from './utils/language';
import { YellowBox } from 'react-native';
import _ from 'lodash';

var config = {
    apiKey: "AIzaSyCI3KCvwX25L_FkdMPcQVeChxNdYJAqFB8",
    authDomain: "aprendiendofirebase-9aa43.firebaseapp.com",
    databaseURL: "https://aprendiendofirebase-9aa43.firebaseio.com",
    projectId: "aprendiendofirebase-9aa43",
    storageBucket: "aprendiendofirebase-9aa43.appspot.com",
    messagingSenderId: "770208484758"
};

firebase.initializeApp(config);
type AppState = {
    ready: boolean

};

const read_localStorage = async () => {
    try {
        const value = await AsyncStorage.getItem('language');
        if (value !== null) {
            // We have data!!
            i18n.locale = value;

        }
    } catch (error) {
        // Error retrieving data
    }
};

read_localStorage();


buttomMargin = (Platform.OS == 'ios') ? -30 : -19


export default class App extends React.Component<{}, AppState> {

    state = {
        ready: false
    };

    componentWillMount() {

        const promises = [];
        promises.push(Font.loadAsync({
            "Avenir-Book": require("./assets/fonts/Avenir-Book.ttf"),
            "Avenir-Light": require("./assets/fonts/Avenir-Light.ttf"),
            "Avenir-Black": require("./assets/fonts/Avenir-Black.ttf"),
        }));
        Promise.all(promises.concat(Images.downloadAsync()))
            .then(() => this.setState({ ready: true }))
            // eslint-disable-next-line
            .catch(error => console.error(error));
    }

    render(): React.Node {
        const { ready } = this.state;
        return (
            <StyleProvider style={getTheme(variables)}>
                {
                    ready
                        ?
                        <AppNavigator onNavigationStateChange={() => undefined} />
                        :
                        <AppLoading startAsync={null} onError={null} onFinish={null} />
                }
            </StyleProvider>
        );
    }
}


const ResourceNavigator = createStackNavigator({
    Resource: { screen: Resources },
    Pdf: { screen: Pdf }
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})

const CreateNavigator = createStackNavigator({
    Create: { screen: Create },
    Create2: { screen: Create2 },
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})


const ChallengeNavigator = createStackNavigator({
    Challenges: { screen: Challenges },
    Create: { screen: Create },
    Create2: { screen: Create2 },
    Mountain: { screen: Mountain }
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})

const MeditateNavigator = createStackNavigator({
    Meditate: { screen: Meditate },
    InAppPurchase:  { screen: InAppPurchase },
    Audios: { screen: Audios },
    AudiosPlayer: { screen: AudiosPlayer },
    Player: { screen: Player },
    Finished: { screen: Finished }
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})

const BreathNavigator = createStackNavigator({
    Breath: { screen: Breath },
    InAppPurchase:  { screen: InAppPurchase },
    Audios: { screen: Audios },
    AudiosPlayer: { screen: AudiosPlayer },
    Player: { screen: Player },
    Finished: { screen: Finished }
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})

const WorkNavigator = createStackNavigator({
    Work: { screen: Work },
    InAppPurchase:  { screen: InAppPurchase },
    Player: { screen: Player },
    AudiosPlayer: {screen: AudiosPlayer},
    Audios: { screen: Audios },
    Finished: { screen: Finished }
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})

const MountainNavigator = createStackNavigator({
    Home: { screen: Home },
    Mountain: { screen: Mountain },
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})

const RootNavigator = createStackNavigator({
    MainStack: { screen: MountainNavigator },
    ModalScreen: { screen: Modal }
}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    },
    mode: 'modal'
})

const MoreNavigator = createStackNavigator({
    Home: { screen: Home },
    Teachers: { screen: Teachers },
    Micromoments: { screen: Micromoments },
    Tools: { screen: Tools },
    Settings: { screen: Settings },
    Terms: { screen: Terms },
    Faq1: { screen: Faq1 },
    Resources: { screen: ResourceNavigator },
    Contact: { screen: Contact },

}, {
    headerMode: 'none',
    navigationOptions: {
        headerVisible: false,
    }
})

/* const MainNavigator = createDrawerNavigator({
   
    Home: { screen: Home },
  

}, {
    drawerWidth: Dimensions.get("window").width,
    // eslint-disable-next-line flowtype/no-weak-types
    contentComponent: (Drawer: any),
    drawerBackgroundColor: variables.brandInfo
}); */

const TabNavigator = createMaterialBottomTabNavigator(

    {
        Home: {
            screen: MountainNavigator, //RootNavigator
            navigationOptions: {
                tabBarLabel: translate('home'),
                tabBarIcon: ({ tintColor }) => (
                    <View>
                        <Image source={Images.iconHome} style={{width: 25, height:27, tintColor: tintColor }}/>
                        {/* <Icon style={[{ color: tintColor }]} size={27} name={'ios-home'} /> */}
                    </View>),
            }
        },
        MinfullBreak: {
            screen: MeditateNavigator,
            navigationOptions: {
                tabBarLabel:  translate('mindfullness'),
                tabBarIcon: ({ tintColor }) => (
                    <View>
                        <Image source={Images.iconBreak} style={{width: 25, height:27, tintColor: tintColor}}/>
                        {/* <Icon style={[{ color: tintColor }]} size={27} name={'ios-apps'} /> */}
                    </View>),
            }
        },
        Challenges: {
            screen: ChallengeNavigator,
            navigationOptions: {
                tabBarLabel:  translate('challenges'),
                tabBarIcon: ({ tintColor }) => (
                    <View>
                        <Image source={Images.iconChallenge} style={{width: 25, height:27, tintColor: tintColor}}/>
                        {/* <Icon style={[{ color: tintColor }]} size={27} name={'ios-rocket'} /> */}
                    </View>),
                /*   <View style={{backgroundColor: COLORS.orange, borderRadius: 90, width: 60, height: 60, alignItems: 'center', justifyContent:'center', borderWidth: 3, borderColor: COLORS.white, marginTop: buttomMargin, position: 'absolute'}}>
                      <FontAwesome5 style={[{ color: COLORS.white, marginTop: 3 }]} size={20} name={'mountain'} />
                  </View>), */
            }
        },
        Work: {
            screen: WorkNavigator,
            navigationOptions: {
                tabBarLabel: translate('work'),
                tabBarIcon: ({ tintColor }) => (
                    <View>
                        <Image source={Images.iconWork} style={{width: 25, height:27, tintColor: tintColor}}/>
                        {/* <Icon style={[{ color: tintColor }]} size={27} name={'ios-stopwatch'} /> */}
                    </View>),
            }
        },
        Breath: {
            screen: BreathNavigator,
            navigationOptions: {
                tabBarLabel: translate('breath'),
                tabBarIcon: ({ tintColor }) => (
                    <View>
                        <Image source={Images.iconBreath} style={{width: 25, height:27, tintColor: tintColor}}/>
                        {/* <Icon style={[{ color: tintColor }]} size={27} name={'ios-moon'} /> */}
                    </View>),
            }
        },
        More: {
            screen: MoreNavigator,

            navigationOptions: ({ navigation }) => ({
                tabBarLabel:  translate('more'),
                tabBarOnPress: () => { navigation.dispatch(DrawerActions.toggleDrawer()) },
                tabBarIcon: ({ tintColor }) => (
                    <View>
                        <Icon style={[{ color: tintColor }]} size={27} name={'ios-more'} />
                    </View>),
            }),
        },

    },
    {
        initialRouteName: "Home",
        labeled: true,
        activeColor: COLORS.orange,
        inactiveColor: COLORS.gray,
        backBehavior: 'order',
        barStyle: {
            // borderWidth: 0.5,
            // borderBottomWidth: 1,
            backgroundColor: 'transparent',
            // borderTopLeftRadius: 30,
            // borderTopRightRadius: 30,
            borderColor: 'transparent',
            overflow: 'visible',
            position: 'absolute', //removes white corners,
        },
    },
);

const DrawerNavigator = createDrawerNavigator(
    {
        Home: { screen: TabNavigator }
    },
    {
        drawerPosition: 'right',
        // eslint-disable-next-line flowtype/no-weak-types
        drawerWidth: Dimensions.get("window").width,
        contentComponent: (Drawer: any)
    }
);



const AppNavigator = createAppContainer(createAnimatedSwitchNavigator({
    Splash: { screen: Splash },
    Login: { screen: Login },
    SignUp: { screen: SignUp },
    //Walkthrough: { screen: Walkthrough },
    Main: { screen: DrawerNavigator },
    // Settings: { screen: Settings },
    // Player: { screen: Player },
    // Home: { screen: Home },
}, {
    headerMode: "none",
    cardStyle: {
        backgroundColor: variables.brandInfo
    },
    // The previous screen will slide to the bottom while the next screen will fade in
    transition: (
        <Transition.Together>
            <Transition.Out
                type="slide-left"
                durationMs={400}
                interpolation="easeIn"
            />
            <Transition.In type="fade" durationMs={500} />
        </Transition.Together>
    )
}));



export { AppNavigator };
