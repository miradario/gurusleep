## React Native Do Purple Sky v1.2.8

Thanks for purchasing the React Native Do Purple Sky.

Follow the documentation to install and get started with the development:

-   [Documentation](https://wcandillon.github.io/react-native-do-purple-sky-documentation/)
-   [Product Page](https://market.nativebase.io/view/react-native-do-purple-sky-theme)
-	[Change Log](https://wcandillon.github.io/react-native-do-purple-sky-documentation/Changelog.html)
-	[License Page](https://market.nativebase.io/licenses)

Happy coding!
